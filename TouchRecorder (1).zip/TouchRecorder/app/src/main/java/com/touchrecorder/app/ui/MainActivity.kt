package com.touchrecorder.app.ui

import android.Manifest
import android.animation.ObjectAnimator
import android.animation.PropertyValuesHolder
import android.animation.ValueAnimator
import android.content.ActivityNotFoundException
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.isVisible
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.snackbar.Snackbar
import com.touchrecorder.app.R
import com.touchrecorder.app.data.AudioSource
import com.touchrecorder.app.data.RecorderSettings
import com.touchrecorder.app.data.SettingsRepository
import com.touchrecorder.app.databinding.ActivityMainBinding
import com.touchrecorder.app.permissions.PermissionManager
import com.touchrecorder.app.recording.ProjectionManager
import com.touchrecorder.app.recording.RecorderError
import com.touchrecorder.app.recording.RecorderEvent
import com.touchrecorder.app.recording.RecorderState
import com.touchrecorder.app.recording.RecorderStateHolder
import com.touchrecorder.app.service.ScreenRecordService
import com.touchrecorder.app.touch.TouchIndicatorManager
import com.touchrecorder.app.util.Formatters
import com.touchrecorder.app.util.applySystemBarPadding
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    private enum class Step { PERMISSIONS, OVERLAY, TOUCHES, CONSENT }

    private lateinit var b: ActivityMainBinding
    private lateinit var repo: SettingsRepository
    private val handler = Handler(Looper.getMainLooper())

    private var noAudioThisSession = false
    private var overlayPromptShown = false
    private var touchPromptShown = false
    private var minimizeOnStart = false
    private var pulse: ObjectAnimator? = null
    private var lastRendered: RecorderState? = null

    private val ticker = object : Runnable {
        override fun run() {
            renderTimer()
            handler.postDelayed(this, 250)
        }
    }

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { onPermissionsResult() }

    private val projectionLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            val data = result.data
            if (result.resultCode == RESULT_OK && data != null) {
                minimizeOnStart = true
                ScreenRecordService.start(this, result.resultCode, data, noAudioThisSession)
            } else {
                Snackbar.make(b.root, R.string.err_projection_denied, Snackbar.LENGTH_LONG)
                    .setAction(R.string.btn_retry) { continueFlow(Step.CONSENT) }
                    .show()
            }
        }

    private val overlaySettingsLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { continueFlow(Step.TOUCHES) }

    private val accessibilityLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { continueFlow(Step.CONSENT) }

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        b = ActivityMainBinding.inflate(layoutInflater)
        setContentView(b.root)
        repo = SettingsRepository(this)
        b.content.applySystemBarPadding(top = true, bottom = true)

        b.recordButton.setOnClickListener { onRecordButton() }
        b.pauseButton.setOnClickListener {
            val st = RecorderStateHolder.state.value as? RecorderState.Recording ?: return@setOnClickListener
            ScreenRecordService.sendAction(
                this,
                if (st.isPaused) ScreenRecordService.ACTION_RESUME else ScreenRecordService.ACTION_PAUSE
            )
        }
        b.settingsButton.setOnClickListener { openSettings() }
        b.settingsCard.setOnClickListener { openSettings() }
        b.quickCard.setOnClickListener { openSettings() }
        listOf(b.qsResolution.root, b.qsFps.root, b.qsAudio.root, b.qsTouches.root).forEach {
            it.setOnClickListener { openSettings() }
        }
        b.recordingsCard.setOnClickListener { startActivity(Intent(this, RecordingsActivity::class.java)) }

        b.qsResolution.icon.setImageResource(R.drawable.ic_aspect_ratio)
        b.qsResolution.label.setText(R.string.qs_resolution)
        b.qsFps.icon.setImageResource(R.drawable.ic_speed)
        b.qsFps.label.setText(R.string.qs_fps)
        b.qsAudio.icon.setImageResource(R.drawable.ic_mic)
        b.qsAudio.label.setText(R.string.qs_audio)
        b.qsTouches.icon.setImageResource(R.drawable.ic_touch)
        b.qsTouches.label.setText(R.string.qs_touches)

        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                launch { RecorderStateHolder.state.collect { render(it) } }
                launch { RecorderStateHolder.events.collect { handleEvent(it) } }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        renderQuickSettings(repo.load())
        handler.post(ticker)
    }

    override fun onPause() {
        handler.removeCallbacks(ticker)
        super.onPause()
    }

    private fun openSettings() = startActivity(Intent(this, SettingsActivity::class.java))

    // ------------------------------------------------------------ start flow

    private fun effectiveSettings(): RecorderSettings =
        repo.load().let { if (noAudioThisSession) it.copy(audioSource = AudioSource.NONE) else it }

    private fun onRecordButton() {
        when (RecorderStateHolder.state.value) {
            RecorderState.Idle -> {
                noAudioThisSession = false
                overlayPromptShown = false
                touchPromptShown = false
                continueFlow(Step.PERMISSIONS)
            }
            is RecorderState.Recording, is RecorderState.Countdown ->
                ScreenRecordService.sendAction(this, ScreenRecordService.ACTION_STOP)
            else -> Unit // preparing / saving: ignore double taps
        }
    }

    private fun continueFlow(step: Step) {
        if (isFinishing || RecorderStateHolder.isBusy) return
        val s = effectiveSettings()
        when (step) {
            Step.PERMISSIONS -> {
                val needed = PermissionManager.runtimePermissionsFor(this, s)
                if (needed.isEmpty()) {
                    continueFlow(Step.OVERLAY)
                } else if (needed.any { shouldShowRequestPermissionRationale(it) }) {
                    MaterialAlertDialogBuilder(this)
                        .setTitle(R.string.perm_title)
                        .setMessage(R.string.perm_rationale_generic)
                        .setPositiveButton(R.string.btn_allow) { _, _ -> permissionLauncher.launch(needed.toTypedArray()) }
                        .setNegativeButton(R.string.btn_cancel, null)
                        .show()
                } else {
                    permissionLauncher.launch(needed.toTypedArray())
                }
            }

            Step.OVERLAY -> {
                if (s.floatingControls && !PermissionManager.canDrawOverlays(this) && !overlayPromptShown) {
                    overlayPromptShown = true
                    MaterialAlertDialogBuilder(this)
                        .setTitle(R.string.perm_overlay_title)
                        .setMessage(R.string.perm_overlay_message)
                        .setPositiveButton(R.string.btn_open_settings) { _, _ ->
                            try {
                                overlaySettingsLauncher.launch(PermissionManager.overlaySettingsIntent(this))
                            } catch (e: ActivityNotFoundException) {
                                continueFlow(Step.TOUCHES)
                            }
                        }
                        .setNegativeButton(R.string.btn_continue_without) { _, _ -> continueFlow(Step.TOUCHES) }
                        .setOnCancelListener { continueFlow(Step.TOUCHES) }
                        .show()
                } else {
                    continueFlow(Step.TOUCHES)
                }
            }

            Step.TOUCHES -> {
                if (s.showTouches && !touchPromptShown &&
                    TouchIndicatorManager.resolveMode(this, s) == TouchIndicatorManager.Active.NONE
                ) {
                    touchPromptShown = true
                    showTouchSetupDialog { continueFlow(Step.CONSENT) }
                } else {
                    continueFlow(Step.CONSENT)
                }
            }

            Step.CONSENT -> {
                val intent = ProjectionManager(this).createConsentIntent()
                if (intent == null) {
                    showError(RecorderError.PROJECTION_FAILED)
                    return
                }
                try {
                    projectionLauncher.launch(intent)
                } catch (e: ActivityNotFoundException) {
                    showError(RecorderError.PROJECTION_FAILED)
                }
            }
        }
    }

    private fun onPermissionsResult() {
        val s = effectiveSettings()

        if (!PermissionManager.hasLegacyStorage(this)) {
            val permanent = !shouldShowRequestPermissionRationale(Manifest.permission.WRITE_EXTERNAL_STORAGE)
            MaterialAlertDialogBuilder(this)
                .setTitle(R.string.perm_storage_title)
                .setMessage(R.string.perm_storage_message)
                .setPositiveButton(if (permanent) R.string.btn_open_settings else R.string.btn_retry) { _, _ ->
                    if (permanent) PermissionManager.safeStart(this, PermissionManager.appSettingsIntent(this))
                    else continueFlow(Step.PERMISSIONS)
                }
                .setNegativeButton(R.string.btn_cancel, null)
                .show()
            return
        }

        if (s.audioSource != AudioSource.NONE && !PermissionManager.hasMic(this)) {
            val permanent = !shouldShowRequestPermissionRationale(Manifest.permission.RECORD_AUDIO)
            val message = getString(R.string.perm_mic_message) +
                if (permanent) "\n\n" + getString(R.string.perm_mic_denied_permanent) else ""
            MaterialAlertDialogBuilder(this)
                .setTitle(R.string.perm_mic_title)
                .setMessage(message)
                .setPositiveButton(if (permanent) R.string.btn_open_settings else R.string.btn_retry) { _, _ ->
                    if (permanent) PermissionManager.safeStart(this, PermissionManager.appSettingsIntent(this))
                    else continueFlow(Step.PERMISSIONS)
                }
                .setNegativeButton(R.string.btn_record_without_audio) { _, _ ->
                    noAudioThisSession = true
                    continueFlow(Step.OVERLAY)
                }
                .setNeutralButton(R.string.btn_cancel, null)
                .show()
            return
        }

        if (!PermissionManager.hasNotifications(this)) {
            Snackbar.make(b.root, R.string.perm_notifications_denied, Snackbar.LENGTH_LONG).show()
        }
        continueFlow(Step.OVERLAY)
    }

    private fun showTouchSetupDialog(onContinue: () -> Unit) {
        val message = getString(R.string.perm_touch_message) + "\n\n" + getString(R.string.accessibility_restricted_hint)
        MaterialAlertDialogBuilder(this)
            .setTitle(R.string.perm_touch_title)
            .setMessage(message)
            .setPositiveButton(R.string.btn_open_accessibility) { _, _ ->
                try {
                    accessibilityLauncher.launch(PermissionManager.accessibilitySettingsIntent())
                } catch (e: ActivityNotFoundException) {
                    onContinue()
                }
            }
            .setNeutralButton(R.string.btn_adb) { _, _ -> showAdbDialog(this, onContinue) }
            .setNegativeButton(R.string.btn_continue_without) { _, _ -> onContinue() }
            .setOnCancelListener { onContinue() }
            .show()
    }

    // ------------------------------------------------------------ rendering

    private fun render(state: RecorderState) {
        val previous = lastRendered
        lastRendered = state
        val recording = state is RecorderState.Recording
        val active = recording || state is RecorderState.Countdown

        b.statusText.setText(
            when (state) {
                RecorderState.Idle -> R.string.status_ready
                RecorderState.Preparing -> R.string.status_preparing
                is RecorderState.Countdown -> R.string.status_countdown
                is RecorderState.Recording -> if (state.isPaused) R.string.status_paused else R.string.status_recording
                RecorderState.Saving -> R.string.status_saving
            }
        )
        b.recordLabel.setText(if (active) R.string.stop_recording else R.string.start_recording)
        b.recordButton.contentDescription = getString(if (active) R.string.stop_recording else R.string.start_recording)
        b.recordButton.isEnabled = state !is RecorderState.Preparing && state !is RecorderState.Saving
        b.recordButton.alpha = if (b.recordButton.isEnabled) 1f else 0.5f

        b.pauseButton.isVisible = recording
        if (state is RecorderState.Recording) {
            b.pauseButton.setText(if (state.isPaused) R.string.resume else R.string.pause)
            b.pauseButton.setIconResource(if (state.isPaused) R.drawable.ic_play else R.drawable.ic_pause)
        }

        // Morph the record dot into a stop square (and back).
        val coreScale = if (active) 0.5f else 1f
        b.recordCore.setBackgroundResource(if (active) R.drawable.bg_record_core_stop else R.drawable.bg_record_core)
        b.recordCore.animate().scaleX(coreScale).scaleY(coreScale).setDuration(220).start()

        if (recording && !(state as RecorderState.Recording).isPaused) startPulse() else stopPulse()
        renderTimer()

        if (minimizeOnStart) {
            val overlay = PermissionManager.canDrawOverlays(this)
            if (state is RecorderState.Recording || (state is RecorderState.Countdown && overlay)) {
                minimizeOnStart = false
                moveTaskToBack(true)
            } else if (state is RecorderState.Idle && previous != null && previous !is RecorderState.Idle) {
                minimizeOnStart = false
            }
        }
    }

    private fun renderTimer() {
        when (val st = RecorderStateHolder.state.value) {
            is RecorderState.Recording -> {
                b.timerText.text = Formatters.elapsed(st.elapsedMs())
                b.timerText.alpha = if (st.isPaused) 0.5f else 1f
            }
            is RecorderState.Countdown -> {
                b.timerText.text = st.secondsLeft.toString()
                b.timerText.alpha = 1f
            }
            else -> {
                b.timerText.text = Formatters.elapsed(0)
                b.timerText.alpha = 0.35f
            }
        }
    }

    private fun startPulse() {
        if (pulse?.isRunning == true) return
        b.pulseRing.alpha = 0.6f
        pulse = ObjectAnimator.ofPropertyValuesHolder(
            b.pulseRing,
            PropertyValuesHolder.ofFloat(View.SCALE_X, 1f, 1.3f),
            PropertyValuesHolder.ofFloat(View.SCALE_Y, 1f, 1.3f),
            PropertyValuesHolder.ofFloat(View.ALPHA, 0.6f, 0f)
        ).apply {
            duration = 1400
            repeatCount = ValueAnimator.INFINITE
            start()
        }
    }

    private fun stopPulse() {
        pulse?.cancel()
        pulse = null
        b.pulseRing.alpha = 0f
        b.pulseRing.scaleX = 1f
        b.pulseRing.scaleY = 1f
    }

    private fun renderQuickSettings(s: RecorderSettings) {
        b.qsResolution.value.text = when (s.resolution) {
            "1080" -> "1080p"
            "720" -> "720p"
            "480" -> "480p"
            else -> getString(R.string.auto)
        }
        b.qsFps.value.text = s.fps.toString()
        b.qsAudio.value.setText(
            when (s.audioSource) {
                AudioSource.NONE -> R.string.audio_short_none
                AudioSource.MIC -> R.string.audio_short_mic
                AudioSource.INTERNAL -> R.string.audio_short_internal
                AudioSource.BOTH -> R.string.audio_short_both
            }
        )
        b.qsAudio.icon.setImageResource(
            when (s.audioSource) {
                AudioSource.NONE -> R.drawable.ic_mic_off
                AudioSource.MIC -> R.drawable.ic_mic
                else -> R.drawable.ic_volume
            }
        )
        b.qsTouches.value.setText(if (s.showTouches) R.string.on else R.string.off)
        b.saveHint.text = getString(R.string.save_hint, s.saveLocation)
    }

    // ------------------------------------------------------------ events

    private fun handleEvent(event: RecorderEvent) {
        when (event) {
            is RecorderEvent.Saved -> {
                val bar = Snackbar.make(b.root, getString(R.string.saved_snackbar, event.displayName), Snackbar.LENGTH_LONG)
                val uri = event.uri
                if (uri != null) bar.setAction(R.string.action_play) { play(uri) }
                else bar.setAction(R.string.recordings) {
                    startActivity(Intent(this, RecordingsActivity::class.java))
                }
                bar.show()
            }
            is RecorderEvent.Failed -> showError(event.error)
            is RecorderEvent.Info -> {
                val text = getString(event.messageRes, *event.args.toTypedArray())
                Snackbar.make(b.root, text, Snackbar.LENGTH_LONG).show()
            }
        }
    }

    private fun showError(error: RecorderError) {
        val builder = MaterialAlertDialogBuilder(this)
            .setTitle(R.string.err_title)
            .setMessage(error.messageRes)
            .setPositiveButton(R.string.btn_ok, null)
        if (error.isSettingsRelated) {
            builder.setNeutralButton(R.string.settings) { _, _ -> openSettings() }
        }
        if (error == RecorderError.MIC_PERMISSION) {
            builder.setNeutralButton(R.string.btn_open_settings) { _, _ ->
                PermissionManager.safeStart(this, PermissionManager.appSettingsIntent(this))
            }
        }
        builder.show()
    }

    private fun play(uri: Uri) {
        try {
            startActivity(
                Intent(Intent.ACTION_VIEW).setDataAndType(uri, "video/mp4")
                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            )
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(this, R.string.no_player, Toast.LENGTH_SHORT).show()
        }
    }

    companion object {
        /** Shared by MainActivity and the settings screen. */
        fun showAdbDialog(activity: AppCompatActivity, onClose: (() -> Unit)? = null) {
            val command = PermissionManager.ADB_GRANT_COMMAND
            MaterialAlertDialogBuilder(activity)
                .setTitle(R.string.adb_title)
                .setMessage(activity.getString(R.string.adb_message, command))
                .setPositiveButton(R.string.btn_copy) { _, _ ->
                    val cm = activity.getSystemService(ClipboardManager::class.java)
                    cm?.setPrimaryClip(ClipData.newPlainText("adb", command))
                    if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU) {
                        Toast.makeText(activity, R.string.adb_copied, Toast.LENGTH_SHORT).show()
                    }
                    onClose?.invoke()
                }
                .setNegativeButton(R.string.btn_ok) { _, _ -> onClose?.invoke() }
                .setOnCancelListener { onClose?.invoke() }
                .show()
        }
    }
}
