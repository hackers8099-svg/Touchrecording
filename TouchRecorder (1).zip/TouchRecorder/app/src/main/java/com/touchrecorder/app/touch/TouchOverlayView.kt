package com.touchrecorder.app.touch

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.os.SystemClock
import android.view.View
import com.touchrecorder.app.data.TouchAnimation
import kotlin.math.PI
import kotlin.math.max
import kotlin.math.sin

/** Full-screen, non-touchable view that draws animated touch circles. */
class TouchOverlayView(context: Context) : View(context) {

    private class Dot(val x: Float, val y: Float, val start: Long)

    private val dots = ArrayList<Dot>()
    private val location = IntArray(2)
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }

    var touchStyle: TouchStyle? = null

    /** [screenX]/[screenY] are absolute screen coordinates. */
    fun showTouch(screenX: Float, screenY: Float) {
        getLocationOnScreen(location)
        dots.add(Dot(screenX - location[0], screenY - location[1], SystemClock.uptimeMillis()))
        if (dots.size > 24) dots.removeAt(0)
        postInvalidateOnAnimation()
    }

    fun clear() {
        dots.clear()
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val s = touchStyle ?: return
        val now = SystemClock.uptimeMillis()
        val iterator = dots.iterator()
        while (iterator.hasNext()) {
            val d = iterator.next()
            val p = (now - d.start).toFloat() / s.durationMs.coerceAtLeast(1)
            if (p >= 1f) {
                iterator.remove()
                continue
            }
            var radius = s.radiusPx
            var alpha = s.alpha.toFloat()
            when (s.animation) {
                TouchAnimation.RIPPLE -> {
                    radius *= 0.6f + 0.6f * p
                    alpha *= 1f - p
                }
                TouchAnimation.FADE -> alpha *= 1f - p
                TouchAnimation.PULSE -> {
                    radius *= 1f + 0.25f * sin(p * PI).toFloat()
                    if (p > 0.7f) alpha *= (1f - p) / 0.3f
                }
                TouchAnimation.NONE -> Unit
            }
            fill.color = s.color
            fill.alpha = alpha.toInt().coerceIn(0, 255)
            canvas.drawCircle(d.x, d.y, radius, fill)

            ring.color = if (s.color == Color.WHITE) Color.DKGRAY else Color.WHITE
            ring.alpha = (alpha * 0.8f).toInt().coerceIn(0, 255)
            ring.strokeWidth = max(2f, radius * 0.08f)
            canvas.drawCircle(d.x, d.y, radius, ring)
        }
        if (dots.isNotEmpty()) postInvalidateOnAnimation()
    }
}
