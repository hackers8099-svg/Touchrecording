package com.touchrecorder.app.touch

import android.content.ComponentName
import android.content.Context
import android.provider.Settings
import android.util.Log
import androidx.preference.PreferenceManager
import com.touchrecorder.app.data.RecorderSettings
import com.touchrecorder.app.data.TouchAnimation
import com.touchrecorder.app.data.TouchMode
import com.touchrecorder.app.permissions.PermissionManager
import com.touchrecorder.app.service.TouchAccessibilityService
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

data class TouchStyle(
    val color: Int,
    val radiusPx: Float,
    val alpha: Int,
    val animation: TouchAnimation,
    val durationMs: Int,
    val sound: Boolean
) {
    companion object {
        fun from(s: RecorderSettings, density: Float) = TouchStyle(
            color = s.touchColor,
            radiusPx = s.touchSizeDp * density / 2f,
            alpha = (s.touchOpacity * 255 / 100).coerceIn(0, 255),
            animation = s.touchAnimation,
            durationMs = s.touchDurationMs,
            sound = s.touchSound
        )
    }
}

/**
 * Shows touches in the recording. Android has no public API that lets an ordinary app observe
 * every touch on screen, so two real mechanisms are supported:
 *
 * 1. SYSTEM – Android's own "Show taps" (Settings.System "show_touches"). Every touch, drawn by
 *    the system and captured by MediaProjection. Requires WRITE_SECURE_SETTINGS, granted once via
 *    ADB. Turned on only while recording and restored afterwards (also after a crash).
 * 2. CUSTOM – TouchAccessibilityService draws circles in a TYPE_ACCESSIBILITY_OVERLAY window with
 *    the user's color/size/opacity/animation/sound at the position of every tapped element
 *    (buttons, list items, links…). Taps on plain canvases (e.g. games) produce no event.
 */
object TouchIndicatorManager {

    enum class Active { NONE, SYSTEM, CUSTOM }

    private const val TAG = "TouchIndicator"
    private const val SHOW_TOUCHES = "show_touches"
    private const val PREF_RESTORE = "sys_show_touches_restore"

    private val _customActive = MutableStateFlow(false)
    val customActive: StateFlow<Boolean> = _customActive

    @Volatile
    var style: TouchStyle? = null
        private set

    @Volatile
    var current: Active = Active.NONE
        private set

    fun isAccessibilityEnabled(context: Context): Boolean {
        val expected = ComponentName(context, TouchAccessibilityService::class.java)
        val enabled = Settings.Secure.getString(
            context.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false
        return enabled.split(':').any { ComponentName.unflattenFromString(it) == expected }
    }

    fun resolveMode(context: Context, s: RecorderSettings): Active {
        if (!s.showTouches) return Active.NONE
        val system = PermissionManager.hasSecureSettings(context)
        val custom = isAccessibilityEnabled(context)
        return when (s.touchMode) {
            TouchMode.SYSTEM -> if (system) Active.SYSTEM else Active.NONE
            TouchMode.CUSTOM -> if (custom) Active.CUSTOM else Active.NONE
            TouchMode.AUTO -> when {
                system -> Active.SYSTEM
                custom -> Active.CUSTOM
                else -> Active.NONE
            }
        }
    }

    fun start(context: Context, s: RecorderSettings): Active {
        var mode = resolveMode(context, s)
        if (mode == Active.SYSTEM && !enableSystemTaps(context)) {
            mode = if (isAccessibilityEnabled(context) && s.touchMode != TouchMode.SYSTEM) Active.CUSTOM
            else Active.NONE
        }
        if (mode == Active.CUSTOM) {
            style = TouchStyle.from(s, context.resources.displayMetrics.density)
            _customActive.value = true
        }
        current = mode
        return mode
    }

    fun stop(context: Context) {
        _customActive.value = false
        if (current == Active.SYSTEM) restoreSystemTaps(context)
        current = Active.NONE
    }

    /** Restores "Show taps" if the app was killed while recording. Call at app start. */
    fun restoreIfNeeded(context: Context) {
        val prefs = PreferenceManager.getDefaultSharedPreferences(context)
        if (prefs.contains(PREF_RESTORE)) restoreSystemTaps(context)
    }

    private fun enableSystemTaps(context: Context): Boolean {
        val prefs = PreferenceManager.getDefaultSharedPreferences(context)
        return try {
            val resolver = context.contentResolver
            val previous = Settings.System.getInt(resolver, SHOW_TOUCHES, 0)
            prefs.edit().putInt(PREF_RESTORE, previous).commit()
            Settings.System.putInt(resolver, SHOW_TOUCHES, 1)
        } catch (e: Exception) {
            Log.w(TAG, "Cannot enable system show_touches", e)
            prefs.edit().remove(PREF_RESTORE).apply()
            false
        }
    }

    private fun restoreSystemTaps(context: Context) {
        val prefs = PreferenceManager.getDefaultSharedPreferences(context)
        val previous = prefs.getInt(PREF_RESTORE, -1)
        if (previous >= 0) {
            try {
                Settings.System.putInt(context.contentResolver, SHOW_TOUCHES, previous)
            } catch (e: Exception) {
                Log.w(TAG, "Cannot restore show_touches", e)
            }
        }
        prefs.edit().remove(PREF_RESTORE).apply()
    }
}
