# Touch Recorder

Duube shaashadda Android-ka adigoo muujinaya taabashada — app Kotlin ah oo dhab ah (MediaProjection + MediaCodec + MediaMuxer), luuqadda ugu horraysa waa Soomaali, English-na waa la heli karaa.

A native Android screen recorder (Kotlin, Material 3) with touch indicators, internal/microphone audio, pause/resume, floating controls and a recordings library. Somali is the default language; English is included.

## APK-ga ka soo dejiso GitHub (ugu fudud)

1. Tab-ka **Actions** → **Build APK** → run-kii ugu dambeeyay.
2. Hoos u dhaadhac **Artifacts** → soo dejiso `TouchRecorder-apk` (zip).
3. Furo zip-ka, ku rakib `app-debug.apk` (ama `app-release.apk`) taleefankaaga.

Si aad gacanta ugu bilowdo: Actions → Build APK → **Run workflow**.

## Build locally

| Tool | Status |
|---|---|
| Android Studio (Ladybug / Meerkat or newer) | ✅ Open the folder, wait for Gradle sync, *Build → Build APK(s)* |
| AndroidIDE | ✅ Open the folder, run `assembleDebug` (needs an AndroidIDE build that supports AGP 8.10; otherwise lower AGP in `build.gradle`) |
| Command line | ✅ `./gradlew assembleDebug` → `app/build/outputs/apk/debug/app-debug.apk` |
| AIDE | ❌ AIDE does not support Kotlin or modern Gradle/AGP 8, so it can't build this project |

Requirements: JDK 17, Android SDK 36. Toolchain: AGP 8.10.1, Gradle 8.13, Kotlin 2.1.21, minSdk 26 (Android 8), targetSdk 36 (Android 16).

`assembleRelease` is signed with the debug key so it installs directly — replace the `signingConfig` in `app/build.gradle` before publishing to Google Play.

## How it works

```
MediaProjection ─► VirtualDisplay ─► Surface ─► H.264 MediaCodec ─┐
                                                                  ├─► MediaMuxer ─► MP4 (MediaStore)
AudioRecord (mic / AudioPlaybackCapture) ─► AAC MediaCodec ───────┘
```

* **ScreenRecordService** – foreground service, type `mediaProjection|microphone` (Android 14+ rules: consent is used once, projection obtained after `startForeground`, callback registered before `createVirtualDisplay`). Notification with Pause / Resume / Stop.
* **RecordingManager** – video encoder, virtual display, pause/resume (encoder suspend + timestamp shift so the file has no gaps).
* **AudioCaptureManager** *(spec: AudioManager)* – mic, internal audio (Android 10+), or both mixed. Probes the hardware before the countdown and reports unsupported combinations in Somali instead of crashing.
* **ProjectionManager** *(spec: MediaProjectionManager — renamed to avoid clashing with the Android class)*.
* **VideoConfigResolver** – checks the encoder's real capabilities; lowers size/FPS step by step when a combination isn't supported.
* **TouchIndicatorManager** – see below.
* **PermissionManager**, **SettingsRepository**, **RecordingsRepository**, **OutputFileManager** (MediaStore, `Movies/Screen Recordings`, `IS_PENDING` while writing).

### Touch indicator — honest limits

Android has no public API that lets a normal app see every touch on screen without blocking it. Two real mechanisms are supported:

1. **System "Show taps"** – every touch, drawn by Android and captured in the video. Needs a one-time grant:
   `adb shell pm grant com.touchrecorder.app android.permission.WRITE_SECURE_SETTINGS`
   (computer, Wireless debugging, LADB or Shizuku). The app turns it on only while recording and restores it afterwards — even after a crash.
2. **Custom circles (Accessibility service)** – your color, size, opacity, animation, duration and tap sound, drawn at every tapped button/list item/link. Taps on plain canvases (e.g. games) don't generate events. On Android 13+ sideloaded apps may need *App info → ⋮ → Allow restricted settings* first.

"Auto" mode uses System when granted, otherwise Custom.

### Other notes

* Resolution options set the **short side** (1080p / 720p / 480p); the long side follows your screen's aspect ratio so there are no black bars. The app never upscales beyond the real screen.
* Floating controls appear in the video (Android can't hide an overlay from MediaProjection).
* Some apps block internal audio capture (calls, DRM video) — that's an Android policy.
* Somali translations were written carefully but a native-speaker review is recommended.
