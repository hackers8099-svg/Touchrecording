package com.touchrecorder.app.service

import android.accessibilityservice.AccessibilityService
import android.graphics.PixelFormat
import android.graphics.Rect
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Build
import android.util.Log
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import com.touchrecorder.app.touch.TouchIndicatorManager
import com.touchrecorder.app.touch.TouchOverlayView
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

/**
 * Draws custom touch circles while a recording is running ("Custom" touch mode).
 *
 * It listens only to click / long-click events, reads the bounds of the element that was
 * tapped and draws a circle there in a TYPE_ACCESSIBILITY_OVERLAY window (no overlay permission
 * needed, never intercepts touches). It does not read, store or send screen content.
 */
class TouchAccessibilityService : AccessibilityService() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var overlay: TouchOverlayView? = null
    private var tone: ToneGenerator? = null
    private val bounds = Rect()

    override fun onServiceConnected() {
        super.onServiceConnected()
        scope.launch {
            TouchIndicatorManager.customActive.collect { active ->
                if (active) attachOverlay() else detachOverlay()
            }
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val view = overlay ?: return
        if (event == null) return
        if (event.eventType != AccessibilityEvent.TYPE_VIEW_CLICKED &&
            event.eventType != AccessibilityEvent.TYPE_VIEW_LONG_CLICKED
        ) return
        val node = event.source ?: return
        try {
            node.getBoundsInScreen(bounds)
        } finally {
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU) {
                @Suppress("DEPRECATION")
                node.recycle()
            }
        }
        if (bounds.isEmpty) return
        view.showTouch(bounds.exactCenterX(), bounds.exactCenterY())
        if (TouchIndicatorManager.style?.sound == true) playClick()
    }

    override fun onInterrupt() = Unit

    private fun attachOverlay() {
        if (overlay != null) return
        val wm = getSystemService(WindowManager::class.java) ?: return
        val view = TouchOverlayView(this).apply { touchStyle = TouchIndicatorManager.style }
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            params.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            params.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        try {
            wm.addView(view, params)
            overlay = view
        } catch (e: Exception) {
            Log.e(TAG, "Cannot add touch overlay", e)
        }
    }

    private fun detachOverlay() {
        val view = overlay ?: return
        overlay = null
        try {
            getSystemService(WindowManager::class.java)?.removeView(view)
        } catch (_: Exception) {
        }
        tone?.release()
        tone = null
    }

    private fun playClick() {
        try {
            if (tone == null) tone = ToneGenerator(AudioManager.STREAM_MUSIC, 60)
            tone?.startTone(ToneGenerator.TONE_PROP_BEEP, 35)
        } catch (e: RuntimeException) {
            Log.w(TAG, "Tap sound unavailable", e)
        }
    }

    override fun onDestroy() {
        detachOverlay()
        scope.cancel()
        super.onDestroy()
    }

    companion object {
        private const val TAG = "TouchA11yService"
    }
}
