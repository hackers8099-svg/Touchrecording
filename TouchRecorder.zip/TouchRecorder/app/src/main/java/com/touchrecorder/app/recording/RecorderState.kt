package com.touchrecorder.app.recording

import android.net.Uri
import android.os.SystemClock
import androidx.annotation.StringRes
import com.touchrecorder.app.R
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow

/** Every failure the recorder can report. Each one maps to a clear, translated message. */
enum class RecorderError(@StringRes val messageRes: Int) {
    PROJECTION_DENIED(R.string.err_projection_denied),
    PROJECTION_FAILED(R.string.err_projection_failed),
    MIC_PERMISSION(R.string.err_mic_permission),
    MIC_FAILED(R.string.err_mic_failed),
    MIC_BUSY_WITH_INTERNAL(R.string.err_mic_busy),
    INTERNAL_AUDIO_UNSUPPORTED(R.string.err_internal_unsupported),
    INTERNAL_AUDIO_FAILED(R.string.err_internal_failed),
    AUDIO_FAILED(R.string.err_audio_failed),
    ENCODER_UNSUPPORTED(R.string.err_encoder_unsupported),
    ENCODER_FAILED(R.string.err_encoder_failed),
    STORAGE_FAILED(R.string.err_storage_failed),
    STORAGE_PERMISSION(R.string.err_storage_permission),
    ALREADY_RECORDING(R.string.err_already_recording),
    FOREGROUND_FAILED(R.string.err_foreground_failed),
    INTERRUPTED(R.string.err_interrupted),
    EMPTY_RECORDING(R.string.err_empty_recording),
    UNKNOWN(R.string.err_unknown);

    /** Errors the user can usually fix by changing a setting. */
    val isSettingsRelated: Boolean
        get() = this in setOf(
            MIC_BUSY_WITH_INTERNAL, INTERNAL_AUDIO_UNSUPPORTED, INTERNAL_AUDIO_FAILED,
            AUDIO_FAILED, ENCODER_UNSUPPORTED, ENCODER_FAILED
        )
}

class RecorderException(val error: RecorderError, cause: Throwable? = null) :
    Exception(error.name, cause)

sealed interface RecorderState {
    data object Idle : RecorderState
    data object Preparing : RecorderState
    data class Countdown(val secondsLeft: Int) : RecorderState
    data class Recording(
        val startElapsed: Long,
        val pausedTotalMs: Long = 0L,
        val pausedSince: Long = -1L
    ) : RecorderState {
        val isPaused: Boolean get() = pausedSince >= 0

        fun elapsedMs(now: Long = SystemClock.elapsedRealtime()): Long =
            ((if (isPaused) pausedSince else now) - startElapsed - pausedTotalMs).coerceAtLeast(0L)
    }

    data object Saving : RecorderState
}

sealed interface RecorderEvent {
    data class Saved(val uri: Uri?, val displayName: String) : RecorderEvent
    data class Failed(val error: RecorderError) : RecorderEvent
    data class Info(@StringRes val messageRes: Int, val args: List<Any> = emptyList()) : RecorderEvent
}

/** Process-wide recorder state shared by the service, activities and overlays. */
object RecorderStateHolder {
    val state = MutableStateFlow<RecorderState>(RecorderState.Idle)
    val events = MutableSharedFlow<RecorderEvent>(extraBufferCapacity = 16)

    val isBusy: Boolean get() = state.value !is RecorderState.Idle
}
