package com.touchrecorder.app.ui

import android.os.Build
import android.os.Bundle
import android.text.InputType
import android.view.View
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.os.LocaleListCompat
import androidx.preference.EditTextPreference
import androidx.preference.ListPreference
import androidx.preference.Preference
import androidx.preference.PreferenceFragmentCompat
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.touchrecorder.app.BuildConfig
import com.touchrecorder.app.R
import com.touchrecorder.app.ThemeHelper
import com.touchrecorder.app.data.AudioSource
import com.touchrecorder.app.data.SettingsRepository
import com.touchrecorder.app.databinding.ActivitySettingsBinding
import com.touchrecorder.app.permissions.PermissionManager
import com.touchrecorder.app.recording.RecorderStateHolder
import com.touchrecorder.app.touch.ShizukuHelper
import com.touchrecorder.app.touch.TouchIndicatorManager
import rikka.shizuku.Shizuku
import com.touchrecorder.app.util.applySystemBarPadding

class SettingsActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        val b = ActivitySettingsBinding.inflate(layoutInflater)
        setContentView(b.root)
        setSupportActionBar(b.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        b.toolbar.setNavigationOnClickListener { finish() }
        if (savedInstanceState == null) {
            supportFragmentManager.beginTransaction()
                .replace(R.id.settingsContainer, SettingsFragment())
                .commit()
        }
    }
}

class SettingsFragment : PreferenceFragmentCompat() {

    private companion object {
        const val KEY_TOUCH_NOTE = "touch_note"
    }

    override fun onCreatePreferences(savedInstanceState: Bundle?, rootKey: String?) {
        setPreferencesFromResource(R.xml.preferences, rootKey)

        // Recording
        val bitrate = findPreference<ListPreference>(SettingsRepository.KEY_BITRATE)
        val customBitrate = findPreference<EditTextPreference>(SettingsRepository.KEY_BITRATE_CUSTOM)
        customBitrate?.isVisible = bitrate?.value == "custom"
        bitrate?.setOnPreferenceChangeListener { _, value ->
            customBitrate?.isVisible = value == "custom"
            true
        }
        customBitrate?.setOnBindEditTextListener { edit ->
            edit.inputType = InputType.TYPE_CLASS_NUMBER
            edit.setSelection(edit.text.length)
        }
        customBitrate?.setOnPreferenceChangeListener { _, value ->
            val ok = (value as? String)?.toIntOrNull()?.let { it in 1..100 } == true
            if (!ok) showMessage(R.string.pref_bitrate_custom_invalid)
            ok
        }
        customBitrate?.summaryProvider = Preference.SummaryProvider<EditTextPreference> { p ->
            getString(R.string.pref_bitrate_custom_summary, p.text ?: "10")
        }

        // Audio: internal audio needs Android 10+
        findPreference<ListPreference>(SettingsRepository.KEY_AUDIO_SOURCE)?.setOnPreferenceChangeListener { _, value ->
            val src = AudioSource.from(value as? String)
            if (src.usesInternal && Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
                showMessage(R.string.err_internal_unsupported)
                false
            } else {
                true
            }
        }

        // Touches. The Accessibility option exists only in the Pro edition; exact touches
        // (Shizuku) and all animation styles are available in both.
        if (!TouchIndicatorManager.customSupported) {
            findPreference<Preference>(SettingsRepository.KEY_TOUCH_ACCESSIBILITY)?.isVisible = false
            findPreference<ListPreference>(SettingsRepository.KEY_TOUCH_MODE)?.let { list ->
                val keep = list.entryValues.indices.filter { list.entryValues[it] != "custom" }
                list.entries = keep.map { list.entries[it] }.toTypedArray()
                list.entryValues = keep.map { list.entryValues[it] }.toTypedArray()
                if (list.value == "custom") list.value = "auto"
            }
        }
        findPreference<Preference>(SettingsRepository.KEY_TOUCH_SHIZUKU)?.setOnPreferenceClickListener {
            onShizukuClicked()
            true
        }
        findPreference<Preference>(KEY_TOUCH_NOTE)?.setSummary(
            if (TouchIndicatorManager.customSupported) R.string.pref_touch_note_pro else R.string.pref_touch_note
        )
        findPreference<Preference>(SettingsRepository.KEY_TOUCH_ACCESSIBILITY)?.setOnPreferenceClickListener {
            val message = getString(R.string.accessibility_explain) + "\n\n" +
                getString(R.string.accessibility_restricted_hint)
            MaterialAlertDialogBuilder(requireContext())
                .setTitle(R.string.pref_touch_accessibility)
                .setMessage(message)
                .setPositiveButton(R.string.btn_open_accessibility) { _, _ ->
                    PermissionManager.safeStart(requireActivity(), PermissionManager.accessibilitySettingsIntent())
                }
                .setNegativeButton(R.string.btn_cancel, null)
                .show()
            true
        }
        findPreference<Preference>(SettingsRepository.KEY_TOUCH_DEV_OPTIONS)?.setOnPreferenceClickListener {
            MaterialAlertDialogBuilder(requireContext())
                .setTitle(R.string.pref_touch_dev)
                .setMessage(R.string.dev_options_message)
                .setPositiveButton(R.string.btn_open_dev_options) { _, _ ->
                    if (!PermissionManager.safeStart(requireActivity(), PermissionManager.developerOptionsIntent())) {
                        showMessage(R.string.dev_options_missing)
                    }
                }
                .setNegativeButton(R.string.btn_cancel, null)
                .show()
            true
        }
        findPreference<Preference>(SettingsRepository.KEY_TOUCH_SYSTEM)?.setOnPreferenceClickListener {
            MainActivity.showAdbDialog(requireActivity() as AppCompatActivity)
            true
        }

        // Controls
        findPreference<Preference>(SettingsRepository.KEY_OVERLAY_PERMISSION)?.setOnPreferenceClickListener {
            PermissionManager.safeStart(requireActivity(), PermissionManager.overlaySettingsIntent(requireContext()))
            true
        }

        // Interface
        findPreference<ListPreference>(SettingsRepository.KEY_THEME)?.setOnPreferenceChangeListener { _, value ->
            ThemeHelper.apply(value as String)
            true
        }
        findPreference<ListPreference>(SettingsRepository.KEY_LANGUAGE)?.setOnPreferenceChangeListener { _, value ->
            val locales = when (value as String) {
                "so" -> LocaleListCompat.forLanguageTags("so")
                "en" -> LocaleListCompat.forLanguageTags("en")
                else -> LocaleListCompat.getEmptyLocaleList()
            }
            AppCompatDelegate.setApplicationLocales(locales)
            true
        }

        findPreference<Preference>(SettingsRepository.KEY_VERSION)?.summary = BuildConfig.VERSION_NAME

        // Do not change the session settings while a recording is running.
        if (RecorderStateHolder.isBusy) showMessage(R.string.settings_next_recording)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        listView.clipToPadding = false
        listView.applySystemBarPadding(top = false, bottom = true)
    }

    private val shizukuPermissionListener = Shizuku.OnRequestPermissionResultListener { _, _ ->
        view?.post { if (isAdded) refreshStatus() }
    }
    private val shizukuBinderListener = Shizuku.OnBinderReceivedListener {
        view?.post { if (isAdded) refreshStatus() }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Shizuku.addRequestPermissionResultListener(shizukuPermissionListener)
        Shizuku.addBinderReceivedListenerSticky(shizukuBinderListener)
    }

    override fun onDestroy() {
        Shizuku.removeRequestPermissionResultListener(shizukuPermissionListener)
        Shizuku.removeBinderReceivedListener(shizukuBinderListener)
        super.onDestroy()
    }

    override fun onResume() {
        super.onResume()
        refreshStatus()
    }

    private fun onShizukuClicked() {
        val activity = requireActivity()
        when (ShizukuHelper.status(activity)) {
            ShizukuHelper.Status.READY -> showMessage(R.string.shizuku_ready_message)
            ShizukuHelper.Status.NO_PERMISSION ->
                if (!ShizukuHelper.requestPermission()) showMessage(R.string.shizuku_permission_denied)
            ShizukuHelper.Status.NOT_RUNNING -> MaterialAlertDialogBuilder(activity)
                .setTitle(R.string.pref_touch_shizuku)
                .setMessage(R.string.shizuku_start_message)
                .setPositiveButton(R.string.btn_open_shizuku) { _, _ ->
                    PermissionManager.safeStart(activity, ShizukuHelper.openShizukuIntent(activity))
                }
                .setNegativeButton(R.string.btn_cancel, null)
                .show()
            ShizukuHelper.Status.NOT_INSTALLED -> MaterialAlertDialogBuilder(activity)
                .setTitle(R.string.pref_touch_shizuku)
                .setMessage(R.string.shizuku_install_message)
                .setPositiveButton(R.string.btn_install_shizuku) { _, _ ->
                    PermissionManager.safeStart(activity, ShizukuHelper.storeIntent())
                }
                .setNegativeButton(R.string.btn_cancel, null)
                .show()
            ShizukuHelper.Status.UNSUPPORTED -> showMessage(R.string.shizuku_unsupported)
        }
    }

    private fun refreshStatus() {
        val ctx = requireContext()
        findPreference<Preference>(SettingsRepository.KEY_TOUCH_SHIZUKU)?.summary = getString(
            when (ShizukuHelper.status(ctx)) {
                ShizukuHelper.Status.READY ->
                    if (PermissionManager.canDrawOverlays(ctx)) R.string.shizuku_status_ready
                    else R.string.shizuku_status_need_overlay
                ShizukuHelper.Status.NO_PERMISSION -> R.string.shizuku_status_permission
                ShizukuHelper.Status.NOT_RUNNING -> R.string.shizuku_status_not_running
                ShizukuHelper.Status.NOT_INSTALLED -> R.string.shizuku_status_not_installed
                ShizukuHelper.Status.UNSUPPORTED -> R.string.shizuku_unsupported
            }
        )
        findPreference<Preference>(SettingsRepository.KEY_TOUCH_ACCESSIBILITY)?.summary = getString(
            if (TouchIndicatorManager.isAccessibilityEnabled(ctx)) R.string.status_enabled
            else R.string.status_accessibility_off
        )
        findPreference<Preference>(SettingsRepository.KEY_TOUCH_DEV_OPTIONS)?.summary = getString(
            when (TouchIndicatorManager.isShowTapsOn(ctx)) {
                true -> R.string.status_enabled
                false -> R.string.status_show_taps_off
                null -> R.string.pref_touch_dev_summary
            }
        )
        findPreference<Preference>(SettingsRepository.KEY_TOUCH_SYSTEM)?.summary = getString(
            if (PermissionManager.hasSecureSettings(ctx)) R.string.status_granted
            else R.string.status_adb_needed
        )
        findPreference<Preference>(SettingsRepository.KEY_OVERLAY_PERMISSION)?.summary = getString(
            if (PermissionManager.canDrawOverlays(ctx)) R.string.status_granted
            else R.string.status_overlay_needed
        )
    }

    private fun showMessage(res: Int) {
        MaterialAlertDialogBuilder(requireContext())
            .setMessage(res)
            .setPositiveButton(R.string.btn_ok, null)
            .show()
    }
}
