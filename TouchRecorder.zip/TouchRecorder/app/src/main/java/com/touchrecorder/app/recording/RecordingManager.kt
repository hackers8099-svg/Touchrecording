package com.touchrecorder.app.recording

import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat
import android.media.projection.MediaProjection
import android.os.Build
import android.os.Bundle
import android.os.SystemClock
import android.util.Log
import android.view.Surface
import java.io.FileDescriptor
import kotlin.concurrent.thread

/**
 * The real recording engine:
 *
 *   MediaProjection ──► VirtualDisplay ──► Surface ──► H.264 MediaCodec ─┐
 *                                                                        ├─► MediaMuxer (MP4)
 *   AudioRecord(s) ──► AAC MediaCodec  (AudioCaptureManager) ────────────┘
 *
 * Pause/resume suspends the encoder input and removes the paused time from all timestamps.
 */
class RecordingManager(
    private val projection: MediaProjection,
    private val plan: VideoPlan,
    private val audio: AudioCaptureManager?,
    fd: FileDescriptor,
    private val onFatalError: (RecorderException) -> Unit
) {
    private val clock = PauseClock()
    private val muxer = MuxerWrapper(fd, if (audio != null) 2 else 1)

    private var codec: MediaCodec? = null
    private var inputSurface: Surface? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var videoThread: Thread? = null
    private var baseUs = 0L

    @Volatile
    private var stopRequestedAt = 0L

    @Volatile
    private var stopped = false

    @Throws(RecorderException::class)
    fun start() {
        try {
            startInternal()
        } catch (e: RecorderException) {
            audio?.release()
            releaseVideo()
            muxer.stop()
            throw e
        } catch (e: Exception) {
            audio?.release()
            releaseVideo()
            muxer.stop()
            throw RecorderException(RecorderError.ENCODER_FAILED, e)
        }
    }

    private fun startInternal() {
        val c = createConfiguredCodec()
        codec = c
        inputSurface = c.createInputSurface()
        c.start()
        baseUs = System.nanoTime() / 1000

        videoThread = thread(name = "TR-video", priority = Thread.MAX_PRIORITY) { drainVideo(c) }

        if (audio != null) {
            audio.onFailure = { e ->
                Log.w(TAG, "Audio failed during recording, continuing with video only", e)
                onFatalError(RecorderException(RecorderError.AUDIO_FAILED, e))
            }
            audio.start(muxer, clock, baseUs)
        }

        val display = try {
            projection.createVirtualDisplay(
                "TouchRecorder",
                plan.width,
                plan.height,
                plan.densityDpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                inputSurface,
                null,
                null
            )
        } catch (e: Exception) {
            throw RecorderException(RecorderError.PROJECTION_FAILED, e)
        }
        virtualDisplay = display ?: throw RecorderException(RecorderError.PROJECTION_FAILED)
    }

    private fun buildFormat(minimal: Boolean): MediaFormat =
        MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, plan.width, plan.height).apply {
            setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
            setInteger(MediaFormat.KEY_BIT_RATE, plan.bitrate)
            setInteger(MediaFormat.KEY_FRAME_RATE, plan.fps)
            setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1)
            // Keep producing frames when the screen is static (value in microseconds).
            setLong(MediaFormat.KEY_REPEAT_PREVIOUS_FRAME_AFTER, 1_000_000L / plan.fps)
            if (!minimal) {
                setInteger(MediaFormat.KEY_BITRATE_MODE, MediaCodecInfo.EncoderCapabilities.BITRATE_MODE_VBR)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    setFloat(MediaFormat.KEY_MAX_FPS_TO_ENCODER, plan.fps.toFloat())
                }
            }
        }

    private fun createConfiguredCodec(): MediaCodec {
        var lastError: Exception? = null
        for (minimal in listOf(false, true)) {
            val c = try {
                MediaCodec.createByCodecName(plan.codecName)
            } catch (e: Exception) {
                throw RecorderException(RecorderError.ENCODER_UNSUPPORTED, e)
            }
            try {
                c.configure(buildFormat(minimal), null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
                return c
            } catch (e: Exception) {
                lastError = e
                Log.w(TAG, "Encoder configure failed (minimal=$minimal)", e)
                c.release()
            }
        }
        throw RecorderException(RecorderError.ENCODER_FAILED, lastError)
    }

    private fun drainVideo(c: MediaCodec) {
        val info = MediaCodec.BufferInfo()
        var track = -1
        try {
            while (true) {
                val idx = c.dequeueOutputBuffer(info, 10_000)
                when {
                    idx == MediaCodec.INFO_TRY_AGAIN_LATER -> {
                        val requested = stopRequestedAt
                        if (requested > 0 && SystemClock.elapsedRealtime() - requested > 2500) break
                    }
                    idx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                        track = muxer.addTrack(c.outputFormat)
                    }
                    idx >= 0 -> {
                        val buf = c.getOutputBuffer(idx)
                        val eos = info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0
                        if (info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG != 0) info.size = 0
                        if (buf != null && info.size > 0 && track >= 0) {
                            val raw = info.presentationTimeUs
                            if (!clock.isPaused(raw)) {
                                val pts = raw - baseUs - clock.offsetFor(raw)
                                if (pts >= 0) {
                                    info.presentationTimeUs = pts
                                    muxer.write(track, buf, info)
                                }
                            }
                        }
                        c.releaseOutputBuffer(idx, false)
                        if (eos) break
                    }
                }
            }
        } catch (e: IllegalStateException) {
            // Codec released while draining, or a codec error.
            if (stopRequestedAt == 0L) {
                Log.e(TAG, "Video encoder failed", e)
                onFatalError(RecorderException(RecorderError.ENCODER_FAILED, e))
            }
        }
    }

    fun pause() {
        clock.pause(System.nanoTime() / 1000)
        setSuspended(true)
    }

    fun resume() {
        setSuspended(false)
        clock.resume(System.nanoTime() / 1000)
        try {
            codec?.setParameters(Bundle().apply { putInt(MediaCodec.PARAMETER_KEY_REQUEST_SYNC_FRAME, 0) })
        } catch (_: Exception) {
        }
    }

    private fun setSuspended(suspend: Boolean) {
        try {
            codec?.setParameters(Bundle().apply {
                putInt(MediaCodec.PARAMETER_KEY_SUSPEND, if (suspend) 1 else 0)
            })
        } catch (e: Exception) {
            Log.w(TAG, "PARAMETER_KEY_SUSPEND not supported; frames are dropped instead", e)
        }
    }

    /**
     * Stops capture, flushes both encoders and finalizes the MP4.
     * Blocking (up to a few seconds) – call from a background thread.
     * @return true if a playable file was written.
     */
    @Synchronized
    fun stop(): Boolean {
        if (stopped) return false
        stopped = true
        try {
            virtualDisplay?.release()
        } catch (_: Exception) {
        }
        virtualDisplay = null

        if (clock.isPausedNow) setSuspended(false)
        stopRequestedAt = SystemClock.elapsedRealtime()
        try {
            codec?.signalEndOfInputStream()
        } catch (e: Exception) {
            Log.w(TAG, "signalEndOfInputStream failed", e)
        }

        audio?.stop()
        try {
            videoThread?.join(4000)
        } catch (_: InterruptedException) {
        }
        videoThread = null
        releaseVideo()
        return muxer.stop()
    }

    private fun releaseVideo() {
        if (stopRequestedAt == 0L) stopRequestedAt = SystemClock.elapsedRealtime()
        codec?.let {
            try {
                it.stop()
            } catch (_: Exception) {
            }
            try {
                it.release()
            } catch (_: Exception) {
            }
        }
        codec = null
        try {
            inputSurface?.release()
        } catch (_: Exception) {
        }
        inputSurface = null
    }

    companion object {
        private const val TAG = "RecordingManager"
    }
}
