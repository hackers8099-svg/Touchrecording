package com.touchrecorder.app.recording

import android.content.ContentValues
import android.content.Context
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.ParcelFileDescriptor
import android.provider.MediaStore
import android.util.Log
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class OutputTarget(
    val uri: Uri?,
    val file: File?,
    val pfd: ParcelFileDescriptor,
    val displayName: String,
    val relativeDir: String
)

data class FinalizeResult(val success: Boolean, val uri: Uri?)

/**
 * Creates the output MP4 through MediaStore (Android 10+: Movies/Screen Recordings via
 * RELATIVE_PATH, marked IS_PENDING until finished) or directly in public storage on Android 8/9.
 * Files created this way stay in the user's gallery even after the app is uninstalled.
 */
object OutputFileManager {

    private const val TAG = "OutputFileManager"

    fun buildFileName(format: String, now: Date = Date()): String {
        val base = when (format) {
            "screen" -> "Screen_" + SimpleDateFormat("yyyy-MM-dd_HH-mm-ss", Locale.US).format(now)
            "timestamp" -> "REC_" + now.time
            else -> "TouchRecorder_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(now)
        }
        return "$base.mp4"
    }

    @Throws(RecorderException::class)
    fun create(context: Context, saveLocation: String, filenameFormat: String): OutputTarget {
        val name = buildFileName(filenameFormat)
        val rel = saveLocation.trim('/')
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val resolver = context.contentResolver
            val values = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, name)
                put(MediaStore.MediaColumns.MIME_TYPE, "video/mp4")
                put(MediaStore.MediaColumns.RELATIVE_PATH, rel)
                put(MediaStore.MediaColumns.IS_PENDING, 1)
                put(MediaStore.MediaColumns.DATE_TAKEN, System.currentTimeMillis())
            }
            val collection = MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
            val inserted: Uri? = try {
                resolver.insert(collection, values)
            } catch (e: Exception) {
                throw RecorderException(RecorderError.STORAGE_FAILED, e)
            }
            val uri = inserted ?: throw RecorderException(RecorderError.STORAGE_FAILED)
            val pfd = try {
                resolver.openFileDescriptor(uri, "rw")
            } catch (e: Exception) {
                null
            }
            if (pfd == null) {
                try {
                    resolver.delete(uri, null, null)
                } catch (_: Exception) {
                }
                throw RecorderException(RecorderError.STORAGE_FAILED)
            }
            OutputTarget(uri, null, pfd, name, rel)
        } else {
            try {
                @Suppress("DEPRECATION")
                val root = Environment.getExternalStorageDirectory()
                val dir = File(root, rel)
                if (!dir.exists() && !dir.mkdirs()) throw RecorderException(RecorderError.STORAGE_FAILED)
                val file = File(dir, name)
                val pfd = ParcelFileDescriptor.open(
                    file,
                    ParcelFileDescriptor.MODE_CREATE or ParcelFileDescriptor.MODE_TRUNCATE or
                        ParcelFileDescriptor.MODE_READ_WRITE
                )
                OutputTarget(null, file, pfd, name, rel)
            } catch (e: RecorderException) {
                throw e
            } catch (e: SecurityException) {
                throw RecorderException(RecorderError.STORAGE_PERMISSION, e)
            } catch (e: Exception) {
                throw RecorderException(RecorderError.STORAGE_FAILED, e)
            }
        }
    }

    /** Publishes the file on success, deletes the half-written file on failure. */
    fun finalize(context: Context, target: OutputTarget, success: Boolean): FinalizeResult {
        try {
            target.pfd.close()
        } catch (e: Exception) {
            Log.w(TAG, "close failed", e)
        }
        val resolver = context.contentResolver
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val uri = target.uri ?: return FinalizeResult(false, null)
            return try {
                if (success) {
                    val values = ContentValues().apply { put(MediaStore.MediaColumns.IS_PENDING, 0) }
                    resolver.update(uri, values, null, null)
                    FinalizeResult(true, uri)
                } else {
                    resolver.delete(uri, null, null)
                    FinalizeResult(false, null)
                }
            } catch (e: Exception) {
                Log.e(TAG, "finalize failed", e)
                FinalizeResult(false, null)
            }
        } else {
            val file = target.file ?: return FinalizeResult(false, null)
            return if (success && file.length() > 0) {
                MediaScannerConnection.scanFile(context, arrayOf(file.absolutePath), arrayOf("video/mp4"), null)
                FinalizeResult(true, null)
            } else {
                file.delete()
                FinalizeResult(false, null)
            }
        }
    }
}
