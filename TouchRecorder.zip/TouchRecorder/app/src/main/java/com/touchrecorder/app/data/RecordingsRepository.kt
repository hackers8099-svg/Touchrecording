package com.touchrecorder.app.data

import android.app.RecoverableSecurityException
import android.content.ContentUris
import android.content.ContentValues
import android.content.Context
import android.content.IntentSender
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import android.util.Log
import android.util.Size
import java.io.File

data class RecordingItem(
    val id: Long,
    val uri: Uri,
    val name: String,
    val dateAddedSec: Long,
    val durationMs: Long,
    val size: Long,
    val relativeDir: String,
    val dataPath: String?
)

sealed interface WriteResult {
    data object Done : WriteResult
    data object Failed : WriteResult

    /** The system must ask the user first. [retryAfter] = run the action again once granted. */
    class NeedsPermission(val sender: IntentSender, val retryAfter: Boolean) : WriteResult
}

/** Reads, renames and deletes recordings through MediaStore. */
class RecordingsRepository(private val context: Context) {

    private val resolver get() = context.contentResolver

    private val collection: Uri =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL)
        else MediaStore.Video.Media.EXTERNAL_CONTENT_URI

    fun query(): List<RecordingItem> {
        val q = Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q
        val locationColumn = if (q) MediaStore.MediaColumns.RELATIVE_PATH else DATA_COLUMN
        val projection = arrayOf(
            MediaStore.MediaColumns._ID,
            MediaStore.MediaColumns.DISPLAY_NAME,
            MediaStore.MediaColumns.DATE_ADDED,
            MediaStore.Video.Media.DURATION,
            MediaStore.MediaColumns.SIZE,
            locationColumn
        )
        val locations = SettingsRepository.SAVE_LOCATIONS
        val selection = locations.joinToString(" OR ") { "$locationColumn LIKE ?" }
        val args = locations.map { if (q) "$it/" else "%/$it/%" }.toTypedArray()

        val items = ArrayList<RecordingItem>()
        try {
            resolver.query(collection, projection, selection, args, "${MediaStore.MediaColumns.DATE_ADDED} DESC")?.use { c ->
                val idCol = c.getColumnIndexOrThrow(MediaStore.MediaColumns._ID)
                val nameCol = c.getColumnIndexOrThrow(MediaStore.MediaColumns.DISPLAY_NAME)
                val dateCol = c.getColumnIndexOrThrow(MediaStore.MediaColumns.DATE_ADDED)
                val durCol = c.getColumnIndex(MediaStore.Video.Media.DURATION)
                val sizeCol = c.getColumnIndexOrThrow(MediaStore.MediaColumns.SIZE)
                val locCol = c.getColumnIndexOrThrow(locationColumn)
                while (c.moveToNext()) {
                    val id = c.getLong(idCol)
                    val location = c.getString(locCol) ?: ""
                    val relativeDir = if (q) location.trimEnd('/')
                    else locations.firstOrNull { location.contains("/$it/") } ?: SettingsRepository.DEFAULT_SAVE_LOCATION
                    items.add(
                        RecordingItem(
                            id = id,
                            uri = ContentUris.withAppendedId(collection, id),
                            name = c.getString(nameCol) ?: "video.mp4",
                            dateAddedSec = c.getLong(dateCol),
                            durationMs = if (durCol >= 0) c.getLong(durCol) else 0L,
                            size = c.getLong(sizeCol),
                            relativeDir = relativeDir,
                            dataPath = if (q) null else location
                        )
                    )
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "query failed", e)
        }
        return items
    }

    fun thumbnail(item: RecordingItem): Bitmap? = try {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            resolver.loadThumbnail(item.uri, Size(320, 180), null)
        } else {
            @Suppress("DEPRECATION")
            MediaStore.Video.Thumbnails.getThumbnail(resolver, item.id, MediaStore.Video.Thumbnails.MINI_KIND, null)
        }
    } catch (e: Exception) {
        null
    }

    fun rename(item: RecordingItem, newBaseName: String): WriteResult {
        val clean = newBaseName.trim().replace(Regex("[\\\\/:*?\"<>|]"), "_").removeSuffix(".mp4")
        if (clean.isEmpty()) return WriteResult.Failed
        val newName = "$clean.mp4"

        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
            val path = item.dataPath ?: return WriteResult.Failed
            val from = File(path)
            val to = File(from.parentFile, newName)
            if (to.exists() || !from.renameTo(to)) return WriteResult.Failed
            val values = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, newName)
                put(DATA_COLUMN, to.absolutePath)
            }
            return try {
                resolver.update(item.uri, values, null, null)
                WriteResult.Done
            } catch (e: Exception) {
                WriteResult.Failed
            }
        }

        return try {
            val values = ContentValues().apply { put(MediaStore.MediaColumns.DISPLAY_NAME, newName) }
            if (resolver.update(item.uri, values, null, null) > 0) WriteResult.Done else WriteResult.Failed
        } catch (e: SecurityException) {
            permissionFor(item, e, isDelete = false)
        } catch (e: Exception) {
            Log.e(TAG, "rename failed", e)
            WriteResult.Failed
        }
    }

    fun delete(item: RecordingItem): WriteResult = try {
        if (resolver.delete(item.uri, null, null) > 0) WriteResult.Done else WriteResult.Failed
    } catch (e: SecurityException) {
        permissionFor(item, e, isDelete = true)
    } catch (e: Exception) {
        Log.e(TAG, "delete failed", e)
        WriteResult.Failed
    }

    /** Files from a previous install are not "owned" by us; Android asks the user to confirm. */
    private fun permissionFor(item: RecordingItem, e: SecurityException, isDelete: Boolean): WriteResult {
        return when {
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.R -> {
                val pi = if (isDelete) MediaStore.createDeleteRequest(resolver, listOf(item.uri))
                else MediaStore.createWriteRequest(resolver, listOf(item.uri))
                // A delete request deletes the file itself once the user agrees.
                WriteResult.NeedsPermission(pi.intentSender, retryAfter = !isDelete)
            }
            Build.VERSION.SDK_INT == Build.VERSION_CODES.Q && e is RecoverableSecurityException ->
                WriteResult.NeedsPermission(e.userAction.actionIntent.intentSender, retryAfter = true)
            else -> WriteResult.Failed
        }
    }

    companion object {
        private const val TAG = "RecordingsRepository"

        @Suppress("DEPRECATION")
        private val DATA_COLUMN = MediaStore.MediaColumns.DATA
    }
}
