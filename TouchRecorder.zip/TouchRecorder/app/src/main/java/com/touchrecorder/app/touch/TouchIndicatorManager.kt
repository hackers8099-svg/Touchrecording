package com.touchrecorder.app.touch

import android.content.ComponentName
import android.content.Context
import android.provider.Settings
import android.util.Log
import androidx.preference.PreferenceManager
import com.touchrecorder.app.BuildConfig
import com.touchrecorder.app.data.RecorderSettings
import com.touchrecorder.app.data.TouchAnimation
import com.touchrecorder.app.data.TouchMode
import com.touchrecorder.app.permissions.PermissionManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

data class TouchStyle(
    val color: Int,
    val radiusPx: Float,
    val alpha: Int,
    val animation: TouchAnimation,
    val durationMs: Int,
    val sound: Boolean
) {
    companion object {
        fun from(s: RecorderSettings, density: Float) = TouchStyle(
            color = s.touchColor,
            radiusPx = s.touchSizeDp * density / 2f,
            alpha = (s.touchOpacity * 255 / 100).coerceIn(0, 255),
            animation = s.touchAnimation,
            durationMs = s.touchDurationMs,
            sound = s.touchSound
        )
    }
}

/**
 * Shows touches in the recording. Two real mechanisms:
 *
 * SYSTEM – Android's own "Show taps" (Settings.System "show_touches"): every touch, white dots.
 *   Turned on automatically while recording after a one-time ADB grant of WRITE_SECURE_SETTINGS,
 *   or manually by the user in Developer options. Works in both editions.
 *
 * CUSTOM – Pro edition only: an Accessibility service draws animated circles (your color, size,
 *   opacity, animation, duration, sound) at every tapped element. Android offers no other public
 *   way to see where the user taps, which is why this lives in a separate edition: Google Play
 *   Protect warns about sideloaded apps that contain an Accessibility service.
 */
object TouchIndicatorManager {

    enum class Active { NONE, SYSTEM_AUTO, SYSTEM_MANUAL, CUSTOM }

    private const val TAG = "TouchIndicator"
    private const val SHOW_TOUCHES = "show_touches"
    private const val PREF_RESTORE = "sys_show_touches_restore"
    private const val SERVICE_CLASS = "com.touchrecorder.app.service.TouchAccessibilityService"

    val customSupported: Boolean get() = BuildConfig.CUSTOM_TOUCHES

    private val _customActive = MutableStateFlow(false)
    val customActive: StateFlow<Boolean> = _customActive

    @Volatile
    var style: TouchStyle? = null
        private set

    @Volatile
    var current: Active = Active.NONE
        private set

    fun isAccessibilityEnabled(context: Context): Boolean {
        if (!customSupported) return false
        val expected = ComponentName(context.packageName, SERVICE_CLASS)
        val enabled = Settings.Secure.getString(
            context.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false
        return enabled.split(':').any { ComponentName.unflattenFromString(it) == expected }
    }

    /** Whether "Show taps" is already on (null if this Android version doesn't let us read it). */
    fun isShowTapsOn(context: Context): Boolean? =
        try {
            Settings.System.getInt(context.contentResolver, SHOW_TOUCHES, 0) == 1
        } catch (e: Exception) {
            null
        }

    private fun systemMode(context: Context): Active = when {
        PermissionManager.hasSecureSettings(context) -> Active.SYSTEM_AUTO
        isShowTapsOn(context) == true -> Active.SYSTEM_MANUAL
        else -> Active.NONE
    }

    fun resolveMode(context: Context, s: RecorderSettings): Active {
        if (!s.showTouches) return Active.NONE
        val custom = isAccessibilityEnabled(context)
        val mode = if (customSupported) s.touchMode else TouchMode.SYSTEM
        return when (mode) {
            TouchMode.SYSTEM -> systemMode(context)
            TouchMode.CUSTOM -> if (custom) Active.CUSTOM else Active.NONE
            TouchMode.AUTO -> if (custom) Active.CUSTOM else systemMode(context)
        }
    }

    fun start(context: Context, s: RecorderSettings): Active {
        var mode = resolveMode(context, s)
        if (mode == Active.SYSTEM_AUTO && !enableSystemTaps(context)) {
            mode = if (isShowTapsOn(context) == true) Active.SYSTEM_MANUAL else Active.NONE
        }
        if (mode == Active.CUSTOM) {
            style = TouchStyle.from(s, context.resources.displayMetrics.density)
            _customActive.value = true
        }
        current = mode
        return mode
    }

    fun stop(context: Context) {
        _customActive.value = false
        if (current == Active.SYSTEM_AUTO) restoreSystemTaps(context)
        current = Active.NONE
    }

    /** Restores "Show taps" if the app was killed while recording. Call at app start. */
    fun restoreIfNeeded(context: Context) {
        val prefs = PreferenceManager.getDefaultSharedPreferences(context)
        if (prefs.contains(PREF_RESTORE)) restoreSystemTaps(context)
    }

    private fun enableSystemTaps(context: Context): Boolean {
        val prefs = PreferenceManager.getDefaultSharedPreferences(context)
        return try {
            val resolver = context.contentResolver
            val previous = Settings.System.getInt(resolver, SHOW_TOUCHES, 0)
            if (previous == 1) return true // already on, nothing to restore later
            prefs.edit().putInt(PREF_RESTORE, previous).commit()
            Settings.System.putInt(resolver, SHOW_TOUCHES, 1)
        } catch (e: Exception) {
            Log.w(TAG, "Cannot enable system show_touches", e)
            prefs.edit().remove(PREF_RESTORE).apply()
            false
        }
    }

    private fun restoreSystemTaps(context: Context) {
        val prefs = PreferenceManager.getDefaultSharedPreferences(context)
        val previous = prefs.getInt(PREF_RESTORE, -1)
        if (previous >= 0) {
            try {
                Settings.System.putInt(context.contentResolver, SHOW_TOUCHES, previous)
            } catch (e: Exception) {
                Log.w(TAG, "Cannot restore show_touches", e)
            }
        }
        prefs.edit().remove(PREF_RESTORE).apply()
    }
}
