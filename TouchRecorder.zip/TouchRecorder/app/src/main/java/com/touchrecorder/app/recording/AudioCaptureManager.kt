package com.touchrecorder.app.recording

import android.annotation.SuppressLint
import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioPlaybackCaptureConfiguration
import android.media.AudioRecord
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat
import android.media.MediaRecorder
import android.media.projection.MediaProjection
import android.os.Build
import android.os.SystemClock
import android.util.Log
import androidx.annotation.RequiresApi
import com.touchrecorder.app.data.AudioQuality
import com.touchrecorder.app.data.AudioSource
import com.touchrecorder.app.permissions.PermissionManager
import java.nio.ByteOrder
import kotlin.concurrent.thread
import kotlin.math.max
import kotlin.math.min

/**
 * Captures microphone and/or internal (device) audio and encodes it to AAC.
 *
 * - Microphone: AudioRecord(MIC)
 * - Internal audio: AudioRecord + AudioPlaybackCaptureConfiguration (Android 10+)
 * - Both: two AudioRecords mixed in software into one stereo track
 *
 * [prepare] probes the hardware before the countdown so unsupported combinations are reported
 * as a clear error instead of crashing during the recording.
 */
class AudioCaptureManager(
    private val context: Context,
    private val projection: MediaProjection,
    private val source: AudioSource,
    quality: AudioQuality,
    micVolume: Int,
    internalVolume: Int
) {
    private val sampleRate = quality.sampleRate
    private val bitrate = quality.bitrate
    private val channels = if (source.usesInternal) 2 else 1
    private val micGain = micVolume / 100f
    private val internalGain = internalVolume / 100f

    private var micRecord: AudioRecord? = null
    private var internalRecord: AudioRecord? = null
    private var encoder: MediaCodec? = null
    private var worker: Thread? = null

    @Volatile
    private var running = false

    /** Invoked (from the audio thread) if audio fails mid-recording. Video keeps going. */
    var onFailure: ((RecorderException) -> Unit)? = null

    @Throws(RecorderException::class)
    fun prepare() {
        if (source == AudioSource.NONE) return
        if (!PermissionManager.hasMic(context)) throw RecorderException(RecorderError.MIC_PERMISSION)
        try {
            if (source.usesInternal) {
                if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
                    throw RecorderException(RecorderError.INTERNAL_AUDIO_UNSUPPORTED)
                }
                internalRecord = createInternalRecord()
            }
            if (source.usesMic) micRecord = createMicRecord()
            probe()
            encoder = createEncoder()
        } catch (e: RecorderException) {
            release()
            throw e
        } catch (e: Exception) {
            release()
            throw RecorderException(RecorderError.AUDIO_FAILED, e)
        }
    }

    /** Starts every AudioRecord briefly to detect devices that refuse a source or the combination. */
    private fun probe() {
        internalRecord?.let { rec ->
            try {
                rec.startRecording()
            } catch (e: Exception) {
                throw RecorderException(RecorderError.INTERNAL_AUDIO_FAILED, e)
            }
            if (rec.recordingState != AudioRecord.RECORDSTATE_RECORDING) {
                throw RecorderException(RecorderError.INTERNAL_AUDIO_FAILED)
            }
        }
        micRecord?.let { rec ->
            val error = if (source == AudioSource.BOTH) RecorderError.MIC_BUSY_WITH_INTERNAL
            else RecorderError.MIC_FAILED
            try {
                rec.startRecording()
            } catch (e: Exception) {
                throw RecorderException(error, e)
            }
            if (rec.recordingState != AudioRecord.RECORDSTATE_RECORDING) throw RecorderException(error)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                SystemClock.sleep(60)
                if (rec.activeRecordingConfiguration?.isClientSilenced == true) {
                    throw RecorderException(error)
                }
            }
        }
        safeStop(internalRecord)
        safeStop(micRecord)
    }

    @SuppressLint("MissingPermission") // checked in prepare()
    private fun createMicRecord(): AudioRecord {
        val minBuf = AudioRecord.getMinBufferSize(
            sampleRate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT
        )
        if (minBuf <= 0) throw RecorderException(RecorderError.MIC_FAILED)
        val rec = AudioRecord(
            MediaRecorder.AudioSource.MIC,
            sampleRate,
            AudioFormat.CHANNEL_IN_MONO,
            AudioFormat.ENCODING_PCM_16BIT,
            max(minBuf, FRAMES * 2 * 4)
        )
        if (rec.state != AudioRecord.STATE_INITIALIZED) {
            rec.release()
            throw RecorderException(RecorderError.MIC_FAILED)
        }
        return rec
    }

    @SuppressLint("MissingPermission") // checked in prepare()
    @RequiresApi(Build.VERSION_CODES.Q)
    private fun createInternalRecord(): AudioRecord {
        val minBuf = AudioRecord.getMinBufferSize(
            sampleRate, AudioFormat.CHANNEL_IN_STEREO, AudioFormat.ENCODING_PCM_16BIT
        )
        if (minBuf <= 0) throw RecorderException(RecorderError.INTERNAL_AUDIO_FAILED)
        val rec = try {
            val config = AudioPlaybackCaptureConfiguration.Builder(projection)
                .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
                .addMatchingUsage(AudioAttributes.USAGE_GAME)
                .addMatchingUsage(AudioAttributes.USAGE_UNKNOWN)
                .build()
            val format = AudioFormat.Builder()
                .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setSampleRate(sampleRate)
                .setChannelMask(AudioFormat.CHANNEL_IN_STEREO)
                .build()
            AudioRecord.Builder()
                .setAudioFormat(format)
                .setBufferSizeInBytes(max(minBuf, FRAMES * 4 * 4))
                .setAudioPlaybackCaptureConfig(config)
                .build()
        } catch (e: Exception) {
            throw RecorderException(RecorderError.INTERNAL_AUDIO_FAILED, e)
        }
        if (rec.state != AudioRecord.STATE_INITIALIZED) {
            rec.release()
            throw RecorderException(RecorderError.INTERNAL_AUDIO_FAILED)
        }
        return rec
    }

    private fun createEncoder(): MediaCodec {
        val format = MediaFormat.createAudioFormat(MediaFormat.MIMETYPE_AUDIO_AAC, sampleRate, channels).apply {
            setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC)
            setInteger(MediaFormat.KEY_BIT_RATE, bitrate)
            setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, FRAMES * channels * 2 * 2)
        }
        val codec = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_AUDIO_AAC)
        try {
            codec.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
        } catch (e: Exception) {
            codec.release()
            throw RecorderException(RecorderError.AUDIO_FAILED, e)
        }
        return codec
    }

    @Throws(RecorderException::class)
    fun start(muxer: MuxerWrapper, clock: PauseClock, baseUs: Long) {
        val enc = encoder ?: throw RecorderException(RecorderError.AUDIO_FAILED)
        try {
            internalRecord?.startRecording()
            micRecord?.startRecording()
            enc.start()
        } catch (e: Exception) {
            throw RecorderException(RecorderError.AUDIO_FAILED, e)
        }
        running = true
        worker = thread(name = "TR-audio", priority = Thread.MAX_PRIORITY) {
            runLoop(enc, muxer, clock, baseUs)
        }
    }

    fun stop() {
        running = false
        // Stopping the records unblocks any pending blocking read().
        safeStop(internalRecord)
        safeStop(micRecord)
        try {
            worker?.join(3000)
        } catch (_: InterruptedException) {
        }
        worker = null
        release()
    }

    fun release() {
        running = false
        internalRecord?.let { safeStop(it); it.release() }
        micRecord?.let { safeStop(it); it.release() }
        internalRecord = null
        micRecord = null
        encoder?.let {
            try {
                it.stop()
            } catch (_: Exception) {
            }
            try {
                it.release()
            } catch (_: Exception) {
            }
        }
        encoder = null
    }

    private fun safeStop(rec: AudioRecord?) {
        try {
            if (rec != null && rec.recordingState == AudioRecord.RECORDSTATE_RECORDING) rec.stop()
        } catch (_: Exception) {
        }
    }

    private fun runLoop(enc: MediaCodec, muxer: MuxerWrapper, clock: PauseClock, baseUs: Long) {
        val out = ShortArray(FRAMES * channels)
        val micBuf = ShortArray(FRAMES)
        val intBuf = ShortArray(FRAMES * 2)
        val tmp = ShortArray(FRAMES * 2 * 4)
        val ring = ShortRing(sampleRate * 2 * 2) // ~2 s of stereo audio
        val info = MediaCodec.BufferInfo()
        var track = -1
        var formatReceived = false

        fun drain(endOfStream: Boolean) {
            val deadline = SystemClock.elapsedRealtime() + 2000
            while (true) {
                val idx = enc.dequeueOutputBuffer(info, if (endOfStream) 10_000 else 0)
                when {
                    idx == MediaCodec.INFO_TRY_AGAIN_LATER -> {
                        if (!endOfStream || SystemClock.elapsedRealtime() > deadline) return
                    }
                    idx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                        track = muxer.addTrack(enc.outputFormat)
                        formatReceived = true
                    }
                    idx >= 0 -> {
                        val buf = enc.getOutputBuffer(idx)
                        val eos = info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0
                        if (info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG != 0) info.size = 0
                        if (buf != null && info.size > 0 && track >= 0) {
                            val raw = info.presentationTimeUs
                            info.presentationTimeUs = raw - baseUs - clock.offsetFor(raw)
                            muxer.write(track, buf, info)
                        }
                        enc.releaseOutputBuffer(idx, false)
                        if (eos) return
                    }
                }
            }
        }

        try {
            while (running) {
                val frames: Int = when (source) {
                    AudioSource.MIC -> {
                        val n = micRecord!!.read(micBuf, 0, FRAMES, AudioRecord.READ_BLOCKING)
                        if (n < 0) throw IllegalStateException("mic read $n")
                        for (i in 0 until n) out[i] = clip(micBuf[i] * micGain)
                        n
                    }
                    AudioSource.INTERNAL -> {
                        val n = internalRecord!!.read(intBuf, 0, FRAMES * 2, AudioRecord.READ_BLOCKING)
                        if (n < 0) throw IllegalStateException("internal read $n")
                        for (i in 0 until n) out[i] = clip(intBuf[i] * internalGain)
                        n / 2
                    }
                    AudioSource.BOTH -> {
                        // The mic drives the timing; internal audio is pulled without blocking
                        // because it may deliver nothing while no app is playing sound.
                        val n = micRecord!!.read(micBuf, 0, FRAMES, AudioRecord.READ_BLOCKING)
                        if (n < 0) throw IllegalStateException("mic read $n")
                        val r = internalRecord!!.read(tmp, 0, tmp.size, AudioRecord.READ_NON_BLOCKING)
                        if (r > 0) ring.write(tmp, r)
                        val got = ring.read(intBuf, n * 2)
                        for (i in 0 until n) {
                            val m = micBuf[i] * micGain
                            val l = if (2 * i < got) intBuf[2 * i] * internalGain else 0f
                            val rr = if (2 * i + 1 < got) intBuf[2 * i + 1] * internalGain else 0f
                            out[2 * i] = clip(l + m)
                            out[2 * i + 1] = clip(rr + m)
                        }
                        n
                    }
                    AudioSource.NONE -> 0
                }
                if (frames <= 0) {
                    if (!running) break
                    continue
                }
                val nowUs = System.nanoTime() / 1000
                val ptsUs = nowUs - frames * 1_000_000L / sampleRate
                if (clock.isPausedNow || clock.isPaused(ptsUs)) {
                    drain(false)
                    continue
                }
                queue(enc, out, frames * channels, ptsUs)
                drain(false)
            }
            // End of stream
            val idx = enc.dequeueInputBuffer(20_000)
            if (idx >= 0) {
                enc.queueInputBuffer(idx, 0, 0, System.nanoTime() / 1000, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
            }
            drain(true)
        } catch (e: Exception) {
            Log.e(TAG, "Audio loop failed", e)
            if (running) onFailure?.invoke(RecorderException(RecorderError.AUDIO_FAILED, e))
        } finally {
            if (!formatReceived) muxer.abandonTrackSlot()
        }
    }

    private fun queue(enc: MediaCodec, pcm: ShortArray, samples: Int, ptsUs: Long) {
        val idx = enc.dequeueInputBuffer(10_000)
        if (idx < 0) return
        val buffer = enc.getInputBuffer(idx) ?: return
        buffer.clear()
        val n = min(samples, buffer.remaining() / 2)
        buffer.order(ByteOrder.nativeOrder()).asShortBuffer().put(pcm, 0, n)
        enc.queueInputBuffer(idx, 0, n * 2, ptsUs, 0)
    }

    private fun clip(v: Float): Short = v.coerceIn(-32768f, 32767f).toInt().toShort()

    /** Small FIFO for internal audio in "internal + microphone" mode. */
    private class ShortRing(capacity: Int) {
        private val data = ShortArray(capacity)
        private var head = 0
        private var size = 0

        fun write(src: ShortArray, count: Int) {
            for (i in 0 until count) {
                if (size == data.size) { // drop oldest to keep latency bounded
                    head = (head + 1) % data.size
                    size--
                }
                data[(head + size) % data.size] = src[i]
                size++
            }
        }

        fun read(dst: ShortArray, count: Int): Int {
            val n = min(count, min(size, dst.size))
            for (i in 0 until n) {
                dst[i] = data[head]
                head = (head + 1) % data.size
            }
            size -= n
            return n
        }
    }

    companion object {
        private const val TAG = "AudioCapture"
        private const val FRAMES = 1024
    }
}
