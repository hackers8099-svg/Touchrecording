package com.touchrecorder.app.util

import android.content.Context
import android.text.format.Formatter
import android.view.View
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import java.text.DateFormat
import java.util.Date
import java.util.Locale

object Formatters {

    /** 65_000 -> "01:05", 3_725_000 -> "1:02:05" */
    fun elapsed(ms: Long): String {
        val total = (ms / 1000).coerceAtLeast(0)
        val h = total / 3600
        val m = (total % 3600) / 60
        val s = total % 60
        return if (h > 0) String.format(Locale.US, "%d:%02d:%02d", h, m, s)
        else String.format(Locale.US, "%02d:%02d", m, s)
    }

    fun size(context: Context, bytes: Long): String = Formatter.formatShortFileSize(context, bytes)

    fun date(epochSeconds: Long): String =
        DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT).format(Date(epochSeconds * 1000))
}

/** Adds system-bar / cutout insets to the view's existing padding (edge-to-edge, Android 15+). */
fun View.applySystemBarPadding(top: Boolean, bottom: Boolean) {
    val l = paddingLeft
    val t = paddingTop
    val r = paddingRight
    val b = paddingBottom
    ViewCompat.setOnApplyWindowInsetsListener(this) { v, insets ->
        val i = insets.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout())
        v.setPadding(
            l + i.left,
            t + if (top) i.top else 0,
            r + i.right,
            b + if (bottom) i.bottom else 0
        )
        insets
    }
}
