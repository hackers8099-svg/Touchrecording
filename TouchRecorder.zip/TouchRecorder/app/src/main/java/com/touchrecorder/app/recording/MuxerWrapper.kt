package com.touchrecorder.app.recording

import android.media.MediaCodec
import android.media.MediaFormat
import android.media.MediaMuxer
import android.util.Log
import java.io.FileDescriptor
import java.nio.ByteBuffer

/**
 * Tracks pause intervals on the shared monotonic clock (microseconds, System.nanoTime based)
 * so that video and audio timestamps stay in sync after pause/resume.
 */
class PauseClock {
    private val closed = ArrayList<LongArray>()
    private var openStart = -1L

    @Synchronized
    fun pause(nowUs: Long) {
        if (openStart < 0) openStart = nowUs
    }

    @Synchronized
    fun resume(nowUs: Long) {
        if (openStart >= 0) {
            closed.add(longArrayOf(openStart, nowUs))
            openStart = -1
        }
    }

    @get:Synchronized
    val isPausedNow: Boolean
        get() = openStart >= 0

    /** True if a sample captured at [ptsUs] falls inside a pause and must be dropped. */
    @Synchronized
    fun isPaused(ptsUs: Long): Boolean {
        if (openStart in 0..ptsUs) return true
        for (iv in closed) if (ptsUs >= iv[0] && ptsUs < iv[1]) return true
        return false
    }

    /** Total paused time before [ptsUs]; subtracted so the output has no gaps. */
    @Synchronized
    fun offsetFor(ptsUs: Long): Long {
        var offset = 0L
        for (iv in closed) if (iv[1] <= ptsUs) offset += iv[1] - iv[0]
        return offset
    }
}

/**
 * Thread-safe wrapper around MediaMuxer. MediaMuxer can only start once every track has been
 * added, so samples that arrive early are buffered until the muxer starts.
 */
class MuxerWrapper(fd: FileDescriptor, expectedTracks: Int) {

    private class Pending(val track: Int, val data: ByteBuffer, val info: MediaCodec.BufferInfo)

    private val muxer = MediaMuxer(fd, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
    private var expected = expectedTracks
    private var added = 0
    private var started = false
    private var stopped = false
    private var samples = 0L
    private val lastPts = HashMap<Int, Long>()
    private val pending = ArrayList<Pending>()

    @Synchronized
    fun addTrack(format: MediaFormat): Int {
        if (started || stopped) return -1
        val track = muxer.addTrack(format)
        added++
        maybeStart()
        return track
    }

    /** Called when a track that was expected (e.g. audio) will never deliver a format. */
    @Synchronized
    fun abandonTrackSlot() {
        if (!started && !stopped && expected > added) {
            expected--
            maybeStart()
        }
    }

    @Synchronized
    fun write(track: Int, buffer: ByteBuffer, info: MediaCodec.BufferInfo) {
        if (stopped || track < 0 || info.size <= 0) return
        if (!started) {
            if (pending.size < MAX_PENDING) {
                pending.add(Pending(track, copy(buffer, info), MediaCodec.BufferInfo().apply {
                    set(0, info.size, info.presentationTimeUs, info.flags)
                }))
                return
            }
            // Waited too long for the other track: start with what we have.
            Log.w(TAG, "Starting muxer without all tracks ($added/$expected)")
            expected = added
            maybeStart()
            if (!started) return
        }
        writeInternal(track, buffer, info)
    }

    /** @return true when a playable file was written. */
    @Synchronized
    fun stop(): Boolean {
        if (stopped) return false
        var ok = false
        try {
            if (!started && added > 0) {
                expected = added
                maybeStart()
            }
            if (started) {
                muxer.stop()
                ok = samples > 0
            }
        } catch (e: Exception) {
            Log.e(TAG, "Muxer stop failed", e)
            ok = false
        } finally {
            stopped = true
            try {
                muxer.release()
            } catch (e: Exception) {
                Log.w(TAG, "Muxer release failed", e)
            }
        }
        return ok
    }

    private fun maybeStart() {
        if (started || added == 0 || added < expected) return
        muxer.start()
        started = true
        for (p in pending) writeInternal(p.track, p.data, p.info)
        pending.clear()
    }

    private fun writeInternal(track: Int, buffer: ByteBuffer, info: MediaCodec.BufferInfo) {
        val last = lastPts[track] ?: -1L
        var pts = info.presentationTimeUs.coerceAtLeast(0L)
        if (pts <= last) pts = last + 1
        lastPts[track] = pts
        val out = MediaCodec.BufferInfo().apply { set(info.offset, info.size, pts, info.flags) }
        try {
            buffer.position(info.offset)
            buffer.limit(info.offset + info.size)
            muxer.writeSampleData(track, buffer, out)
            samples++
        } catch (e: Exception) {
            Log.w(TAG, "writeSampleData failed", e)
        }
    }

    private fun copy(src: ByteBuffer, info: MediaCodec.BufferInfo): ByteBuffer {
        val dup = src.duplicate()
        dup.position(info.offset)
        dup.limit(info.offset + info.size)
        val copy = ByteBuffer.allocate(info.size)
        copy.put(dup)
        copy.flip()
        return copy
    }

    companion object {
        private const val TAG = "MuxerWrapper"
        private const val MAX_PENDING = 240
    }
}
