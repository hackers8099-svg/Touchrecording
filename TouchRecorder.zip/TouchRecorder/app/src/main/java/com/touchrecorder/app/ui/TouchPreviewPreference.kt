package com.touchrecorder.app.ui

import android.annotation.SuppressLint
import android.content.Context
import android.util.AttributeSet
import android.view.MotionEvent
import androidx.preference.Preference
import androidx.preference.PreferenceViewHolder
import com.touchrecorder.app.R
import com.touchrecorder.app.data.SettingsRepository
import com.touchrecorder.app.touch.TouchOverlayView
import com.touchrecorder.app.touch.TouchStyle

/** A "tap here to try it" area on the settings screen that previews the chosen touch style. */
class TouchPreviewPreference @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : Preference(context, attrs) {

    init {
        layoutResource = R.layout.preference_touch_preview
        isSelectable = false
        isPersistent = false
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onBindViewHolder(holder: PreferenceViewHolder) {
        super.onBindViewHolder(holder)
        val overlay = holder.findViewById(R.id.previewOverlay) as TouchOverlayView
        holder.findViewById(R.id.previewArea).setOnTouchListener { _, e ->
            if (e.actionMasked == MotionEvent.ACTION_DOWN ||
                e.actionMasked == MotionEvent.ACTION_POINTER_DOWN
            ) {
                val settings = SettingsRepository(context).load()
                overlay.touchStyle = TouchStyle.from(settings, context.resources.displayMetrics.density)
                val index = e.actionIndex
                val offsetX = e.rawX - e.x
                val offsetY = e.rawY - e.y
                overlay.showTouch(e.getX(index) + offsetX, e.getY(index) + offsetY)
            }
            true
        }
    }
}
