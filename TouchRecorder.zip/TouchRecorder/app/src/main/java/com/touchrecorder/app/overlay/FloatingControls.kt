package com.touchrecorder.app.overlay

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.PixelFormat
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.ContextThemeWrapper
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import android.widget.ImageButton
import android.widget.TextView
import com.touchrecorder.app.R
import com.touchrecorder.app.permissions.PermissionManager
import com.touchrecorder.app.recording.RecorderState
import com.touchrecorder.app.recording.RecorderStateHolder
import com.touchrecorder.app.util.Formatters
import kotlin.math.abs

/**
 * Draggable floating controls (timer, pause/resume, stop) and the big countdown number,
 * shown over other apps. Requires "Display over other apps"; silently disabled without it.
 */
class FloatingControls(context: Context, private val callbacks: Callbacks) {

    interface Callbacks {
        fun onPauseResumeClicked()
        fun onStopClicked()
    }

    private val ctx = ContextThemeWrapper(context, R.style.Theme_TouchRecorder)
    private val wm = context.getSystemService(WindowManager::class.java)
    private val handler = Handler(Looper.getMainLooper())

    private var controls: View? = null
    private var controlParams: WindowManager.LayoutParams? = null
    private var countdown: TextView? = null

    private val ticker = object : Runnable {
        override fun run() {
            refresh()
            handler.postDelayed(this, 500)
        }
    }

    fun available(): Boolean = wm != null && PermissionManager.canDrawOverlays(ctx)

    fun showCountdown(seconds: Int) {
        if (!available()) return
        val view = countdown ?: (LayoutInflater.from(ctx).inflate(R.layout.overlay_countdown, null) as TextView).also { tv ->
            val params = baseParams(
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
            ).apply { gravity = Gravity.CENTER }
            if (!add(tv, params)) return
            countdown = tv
        }
        view.text = seconds.toString()
        view.scaleX = 1.3f
        view.scaleY = 1.3f
        view.alpha = 0.4f
        view.animate().scaleX(1f).scaleY(1f).alpha(1f).setDuration(350).start()
    }

    fun hideCountdown() {
        countdown?.let { remove(it) }
        countdown = null
    }

    @SuppressLint("ClickableViewAccessibility")
    fun showControls() {
        if (controls != null || !available()) return
        val view = LayoutInflater.from(ctx).inflate(R.layout.overlay_controls, null)
        val density = ctx.resources.displayMetrics.density
        val params = baseParams(WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE).apply {
            gravity = Gravity.TOP or Gravity.START
            x = (12 * density).toInt()
            y = (160 * density).toInt()
        }
        view.findViewById<ImageButton>(R.id.floatingPause).setOnClickListener { callbacks.onPauseResumeClicked() }
        view.findViewById<ImageButton>(R.id.floatingStop).setOnClickListener { callbacks.onStopClicked() }

        val slop = ViewConfiguration.get(ctx).scaledTouchSlop
        var downX = 0f
        var downY = 0f
        var startX = 0
        var startY = 0
        view.findViewById<View>(R.id.floatingHandle).setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX; downY = e.rawY; startX = params.x; startY = params.y
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - downX
                    val dy = e.rawY - downY
                    if (abs(dx) > slop || abs(dy) > slop) {
                        params.x = startX + dx.toInt()
                        params.y = startY + dy.toInt()
                        try {
                            wm?.updateViewLayout(view, params)
                        } catch (_: Exception) {
                        }
                    }
                    true
                }
                else -> true
            }
        }
        if (add(view, params)) {
            controls = view
            controlParams = params
            handler.post(ticker)
        }
    }

    fun refresh() {
        val view = controls ?: return
        val state = RecorderStateHolder.state.value as? RecorderState.Recording ?: return
        view.findViewById<TextView>(R.id.floatingTimer).text = Formatters.elapsed(state.elapsedMs())
        val pause = view.findViewById<ImageButton>(R.id.floatingPause)
        pause.setImageResource(if (state.isPaused) R.drawable.ic_play else R.drawable.ic_pause)
        pause.contentDescription = ctx.getString(if (state.isPaused) R.string.resume else R.string.pause)
        view.findViewById<View>(R.id.floatingDot).alpha = if (state.isPaused) 0.35f else 1f
    }

    fun hideControls() {
        handler.removeCallbacks(ticker)
        controls?.let { remove(it) }
        controls = null
        controlParams = null
    }

    fun hideAll() {
        hideCountdown()
        hideControls()
    }

    private fun baseParams(flags: Int) = WindowManager.LayoutParams(
        WindowManager.LayoutParams.WRAP_CONTENT,
        WindowManager.LayoutParams.WRAP_CONTENT,
        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        flags,
        PixelFormat.TRANSLUCENT
    )

    private fun add(view: View, params: WindowManager.LayoutParams): Boolean =
        try {
            wm?.addView(view, params)
            wm != null
        } catch (e: Exception) {
            Log.w("FloatingControls", "addView failed", e)
            false
        }

    private fun remove(view: View) {
        try {
            wm?.removeView(view)
        } catch (_: Exception) {
        }
    }
}
