package com.touchrecorder.app.touch

import android.content.Context
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.input.InputManager
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.util.DisplayMetrics
import android.util.Log
import android.view.Display
import android.view.Surface
import android.view.WindowManager
import kotlin.math.min

/**
 * "Exact" touch mode: a full-screen, non-touchable overlay that draws an animation at the exact
 * position of every finger, fed by [RawTouchReader] (via Shizuku). Works over every app,
 * including games and empty areas, and also shows swipes.
 *
 * Android 12+ blocks touches that pass through another app's overlay unless the overlay's alpha
 * is at most InputManager.getMaximumObscuringOpacityForTouch() (0.8) – the window alpha is
 * capped accordingly so the phone stays fully usable while recording.
 */
class ExactTouchOverlay(private val context: Context, private val style: TouchStyle) : RawTouchReader.Listener {

    private val main = Handler(Looper.getMainLooper())
    private val wm = context.getSystemService(WindowManager::class.java)
    private val display: Display? =
        context.getSystemService(DisplayManager::class.java)?.getDisplay(Display.DEFAULT_DISPLAY)
    private var view: TouchOverlayView? = null
    private var reader: RawTouchReader? = null
    private var tone: ToneGenerator? = null

    /** @return false when the overlay or the touch reader could not start. */
    fun start(): Boolean {
        val w = wm ?: return false
        val v = TouchOverlayView(context).apply { touchStyle = style }
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        params.alpha = maxPassThroughAlpha()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            params.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            params.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        try {
            w.addView(v, params)
        } catch (e: Exception) {
            Log.e(TAG, "Cannot add exact touch overlay", e)
            return false
        }
        view = v
        val r = RawTouchReader(this)
        if (!r.start()) {
            stop()
            return false
        }
        reader = r
        return true
    }

    fun stop() {
        reader?.stop()
        reader = null
        main.removeCallbacksAndMessages(null)
        view?.let {
            try {
                wm?.removeView(it)
            } catch (_: Exception) {
            }
        }
        view = null
        tone?.release()
        tone = null
    }

    private fun maxPassThroughAlpha(): Float {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) return 1f
        val max = try {
            context.getSystemService(InputManager::class.java)?.maximumObscuringOpacityForTouch ?: 0.8f
        } catch (e: Exception) {
            0.8f
        }
        return min(max, 0.8f)
    }

    // ---- RawTouchReader.Listener (called on the reader thread) ----

    override fun onDown(pointer: Int, nx: Float, ny: Float) {
        main.post {
            val (x, y) = toScreen(nx, ny)
            view?.pointerDown(pointer, x, y)
            if (style.sound) playClick()
        }
    }

    override fun onMove(pointer: Int, nx: Float, ny: Float) {
        main.post {
            val (x, y) = toScreen(nx, ny)
            view?.pointerMove(pointer, x, y)
        }
    }

    override fun onUp(pointer: Int) {
        main.post { view?.pointerUp(pointer) }
    }

    /** Maps panel coordinates (natural orientation, 0..1) to the current screen. */
    private fun toScreen(nx: Float, ny: Float): Pair<Float, Float> {
        val metrics = realMetrics()
        val rotation = display?.rotation ?: Surface.ROTATION_0
        val w = metrics.widthPixels.toFloat()
        val h = metrics.heightPixels.toFloat()
        return when (rotation) {
            Surface.ROTATION_90 -> ny * w to (1f - nx) * h
            Surface.ROTATION_180 -> (1f - nx) * w to (1f - ny) * h
            Surface.ROTATION_270 -> (1f - ny) * w to nx * h
            else -> nx * w to ny * h
        }
    }

    @Suppress("DEPRECATION")
    private fun realMetrics(): DisplayMetrics {
        val metrics = DisplayMetrics()
        val d = display
        if (d != null) d.getRealMetrics(metrics) else metrics.setTo(context.resources.displayMetrics)
        return metrics
    }

    private fun playClick() {
        try {
            if (tone == null) tone = ToneGenerator(AudioManager.STREAM_MUSIC, 60)
            tone?.startTone(ToneGenerator.TONE_PROP_BEEP, 35)
        } catch (e: RuntimeException) {
            Log.w(TAG, "Tap sound unavailable", e)
        }
    }

    companion object {
        private const val TAG = "ExactTouchOverlay"
    }
}
