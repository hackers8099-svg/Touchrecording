package com.touchrecorder.app.service

import android.app.Activity
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.media.projection.MediaProjection
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.util.Log
import android.widget.Toast
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import androidx.core.content.IntentCompat
import com.touchrecorder.app.R
import com.touchrecorder.app.data.AudioSource
import com.touchrecorder.app.data.RecorderSettings
import com.touchrecorder.app.data.SettingsRepository
import com.touchrecorder.app.overlay.FloatingControls
import com.touchrecorder.app.permissions.PermissionManager
import com.touchrecorder.app.recording.AudioCaptureManager
import com.touchrecorder.app.recording.OutputFileManager
import com.touchrecorder.app.recording.OutputTarget
import com.touchrecorder.app.recording.ProjectionManager
import com.touchrecorder.app.recording.RecorderError
import com.touchrecorder.app.recording.RecorderEvent
import com.touchrecorder.app.recording.RecorderException
import com.touchrecorder.app.recording.RecorderState
import com.touchrecorder.app.recording.RecorderStateHolder
import com.touchrecorder.app.recording.RecordingManager
import com.touchrecorder.app.recording.ShakeDetector
import com.touchrecorder.app.recording.VideoConfigResolver
import com.touchrecorder.app.recording.VideoPlan
import com.touchrecorder.app.touch.TouchIndicatorManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Foreground service (type mediaProjection | microphone) that owns the whole recording session:
 * MediaProjection, encoders, output file, notification, floating controls and touch indicator.
 * Only one session can exist at a time.
 */
class ScreenRecordService : Service(), FloatingControls.Callbacks {

    companion object {
        private const val TAG = "ScreenRecordService"
        private const val ACTION_START = "com.touchrecorder.app.action.START"
        const val ACTION_PAUSE = "com.touchrecorder.app.action.PAUSE"
        const val ACTION_RESUME = "com.touchrecorder.app.action.RESUME"
        const val ACTION_STOP = "com.touchrecorder.app.action.STOP"
        private const val EXTRA_RESULT_CODE = "result_code"
        private const val EXTRA_RESULT_DATA = "result_data"
        private const val EXTRA_NO_AUDIO = "no_audio"

        fun start(context: Context, resultCode: Int, data: Intent, noAudio: Boolean) {
            val intent = Intent(context, ScreenRecordService::class.java)
                .setAction(ACTION_START)
                .putExtra(EXTRA_RESULT_CODE, resultCode)
                .putExtra(EXTRA_RESULT_DATA, data)
                .putExtra(EXTRA_NO_AUDIO, noAudio)
            ContextCompat.startForegroundService(context, intent)
        }

        fun sendAction(context: Context, action: String) {
            try {
                context.startService(Intent(context, ScreenRecordService::class.java).setAction(action))
            } catch (e: Exception) {
                Log.w(TAG, "sendAction($action) failed", e)
            }
        }
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private val mainHandler = Handler(Looper.getMainLooper())
    private lateinit var settingsRepo: SettingsRepository
    private lateinit var notifications: RecorderNotifications

    private var floating: FloatingControls? = null
    private var projection: MediaProjection? = null
    private var recorder: RecordingManager? = null
    private var audio: AudioCaptureManager? = null
    private var output: OutputTarget? = null
    private var countdownJob: Job? = null
    private var stopping = false
    private var pausedByLock = false
    private var screenReceiverRegistered = false
    private var settings: RecorderSettings? = null
    private var shakeDetector: ShakeDetector? = null

    private val projectionCallback = object : MediaProjection.Callback() {
        override fun onStop() {
            // The system ended the projection (status-bar chip, another app, lock policy…)
            mainHandler.post {
                if (!stopping && RecorderStateHolder.isBusy) stopRecording(interrupted = true)
            }
        }
    }

    private val screenReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            val st = RecorderStateHolder.state.value as? RecorderState.Recording ?: return
            when (intent.action) {
                Intent.ACTION_SCREEN_OFF -> if (!st.isPaused) {
                    pausedByLock = true
                    pause()
                }
                Intent.ACTION_USER_PRESENT -> if (pausedByLock) {
                    pausedByLock = false
                    resume()
                }
            }
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        settingsRepo = SettingsRepository(this)
        notifications = RecorderNotifications(this)
        notifications.createChannels()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> handleStart(intent)
            ACTION_PAUSE -> if (RecorderStateHolder.isBusy) pause() else stopSelf()
            ACTION_RESUME -> if (RecorderStateHolder.isBusy) resume() else stopSelf()
            ACTION_STOP -> stopRecording(interrupted = false)
            else -> if (!RecorderStateHolder.isBusy) stopSelf()
        }
        return START_NOT_STICKY
    }

    // ---------------------------------------------------------------- start

    private fun handleStart(intent: Intent) {
        if (RecorderStateHolder.isBusy || projection != null) {
            // Never run two sessions. Still satisfy the startForegroundService() contract.
            if (projection == null) promoteToForeground(audioType = false)
            RecorderStateHolder.events.tryEmit(RecorderEvent.Failed(RecorderError.ALREADY_RECORDING))
            return
        }
        RecorderStateHolder.state.value = RecorderState.Preparing

        val noAudio = intent.getBooleanExtra(EXTRA_NO_AUDIO, false)
        val s = settingsRepo.load().let { if (noAudio) it.copy(audioSource = AudioSource.NONE) else it }
        settings = s
        val wantsAudio = s.audioSource != AudioSource.NONE
        val micGranted = PermissionManager.hasMic(this)

        if (!promoteToForeground(audioType = wantsAudio && micGranted)) {
            fail(RecorderError.FOREGROUND_FAILED)
            return
        }
        if (wantsAudio && !micGranted) {
            fail(RecorderError.MIC_PERMISSION)
            return
        }

        val code = intent.getIntExtra(EXTRA_RESULT_CODE, Activity.RESULT_CANCELED)
        val data = IntentCompat.getParcelableExtra(intent, EXTRA_RESULT_DATA, Intent::class.java)
        if (code != Activity.RESULT_OK || data == null) {
            fail(RecorderError.PROJECTION_DENIED)
            return
        }
        val mp = ProjectionManager(this).obtain(code, data)
        if (mp == null) {
            fail(RecorderError.PROJECTION_FAILED)
            return
        }
        projection = mp
        // Android 14+: the callback must be registered before createVirtualDisplay().
        mp.registerCallback(projectionCallback, mainHandler)

        // Validate video + audio BEFORE the countdown so problems are reported immediately.
        val plan = try {
            VideoConfigResolver.resolve(this, s)
        } catch (e: RecorderException) {
            fail(e.error)
            return
        } catch (e: Exception) {
            Log.e(TAG, "resolve failed", e)
            fail(RecorderError.ENCODER_UNSUPPORTED)
            return
        }
        if (plan.adjusted) {
            RecorderStateHolder.events.tryEmit(
                RecorderEvent.Info(R.string.adjusted_quality, listOf(plan.width, plan.height, plan.fps))
            )
            toast(getString(R.string.adjusted_quality, plan.width, plan.height, plan.fps))
        }
        if (wantsAudio) {
            val capture = AudioCaptureManager(
                this, mp, s.audioSource, s.audioQuality, s.micVolume, s.internalVolume
            )
            try {
                capture.prepare()
            } catch (e: RecorderException) {
                fail(e.error)
                return
            }
            audio = capture
        }

        floating = FloatingControls(this, this)
        countdownJob = scope.launch {
            for (n in s.countdownSeconds downTo 1) {
                val st = RecorderState.Countdown(n)
                RecorderStateHolder.state.value = st
                notifications.updateRecording(st)
                floating?.showCountdown(n)
                delay(1000)
            }
            floating?.hideCountdown()
            if (s.countdownSeconds > 0) delay(200) // make sure the countdown is gone from the screen
            beginRecording(s, plan)
        }
    }

    /** startForeground() with the right service types for Android 10/11/14+. */
    private fun promoteToForeground(audioType: Boolean): Boolean {
        var type = 0
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            type = ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
        }
        if (audioType && Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            type = type or ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
        }
        return try {
            ServiceCompat.startForeground(
                this,
                RecorderNotifications.ID_RECORDING,
                notifications.buildRecording(RecorderStateHolder.state.value),
                type
            )
            true
        } catch (e: Exception) {
            Log.e(TAG, "startForeground failed", e)
            false
        }
    }

    private fun beginRecording(s: RecorderSettings, plan: VideoPlan) {
        val mp = projection ?: return fail(RecorderError.PROJECTION_FAILED)
        val out = try {
            OutputFileManager.create(this, s.saveLocation, s.filenameFormat)
        } catch (e: RecorderException) {
            return fail(e.error)
        }
        output = out
        val rec = RecordingManager(mp, plan, audio, out.pfd.fileDescriptor) { e ->
            mainHandler.post { onRecorderProblem(e) }
        }
        try {
            rec.start()
        } catch (e: RecorderException) {
            Log.e(TAG, "start failed", e)
            return fail(e.error)
        } catch (e: Exception) {
            Log.e(TAG, "start failed", e)
            return fail(RecorderError.ENCODER_FAILED)
        }
        recorder = rec

        val st = RecorderState.Recording(SystemClock.elapsedRealtime())
        RecorderStateHolder.state.value = st
        notifications.updateRecording(st)

        val touchMode = TouchIndicatorManager.start(this, s)
        if (s.showTouches && touchMode == TouchIndicatorManager.Active.NONE) {
            RecorderStateHolder.events.tryEmit(RecorderEvent.Info(R.string.touches_unavailable))
        }
        if (s.floatingControls) floating?.showControls()
        if (s.pauseOnLock) registerScreenReceiver()
        if (s.shakeToStop) {
            val detector = ShakeDetector(this) {
                mainHandler.post { stopRecording(interrupted = false) }
            }
            if (detector.start()) shakeDetector = detector
        }
    }

    private fun onRecorderProblem(e: RecorderException) {
        if (e.error == RecorderError.AUDIO_FAILED) {
            // Audio died (e.g. another app took the microphone) – keep the video going.
            RecorderStateHolder.events.tryEmit(RecorderEvent.Info(R.string.audio_stopped_midway))
            toast(getString(R.string.audio_stopped_midway))
        } else {
            stopRecording(interrupted = true)
        }
    }

    // ---------------------------------------------------------------- pause / resume

    private fun pause() {
        val st = RecorderStateHolder.state.value as? RecorderState.Recording ?: return
        if (st.isPaused || stopping) return
        recorder?.pause()
        val next = st.copy(pausedSince = SystemClock.elapsedRealtime())
        RecorderStateHolder.state.value = next
        notifications.updateRecording(next)
        floating?.refresh()
    }

    private fun resume() {
        val st = RecorderStateHolder.state.value as? RecorderState.Recording ?: return
        if (!st.isPaused || stopping) return
        recorder?.resume()
        val now = SystemClock.elapsedRealtime()
        val next = st.copy(pausedTotalMs = st.pausedTotalMs + (now - st.pausedSince), pausedSince = -1L)
        RecorderStateHolder.state.value = next
        notifications.updateRecording(next)
        floating?.refresh()
    }

    override fun onPauseResumeClicked() {
        val st = RecorderStateHolder.state.value as? RecorderState.Recording ?: return
        pausedByLock = false
        if (st.isPaused) resume() else pause()
    }

    override fun onStopClicked() = stopRecording(interrupted = false)

    // ---------------------------------------------------------------- stop

    private fun stopRecording(interrupted: Boolean) {
        if (stopping) return
        when (RecorderStateHolder.state.value) {
            is RecorderState.Recording -> Unit
            is RecorderState.Countdown, RecorderState.Preparing -> {
                // Cancelled before anything was recorded.
                cleanupSession()
                RecorderStateHolder.state.value = RecorderState.Idle
                finishService()
                return
            }
            else -> {
                if (recorder == null) {
                    finishService()
                    return
                }
            }
        }
        stopping = true
        countdownJob?.cancel()
        floating?.hideAll()
        TouchIndicatorManager.stop(this)
        unregisterScreenReceiver()
        stopShakeDetector()
        RecorderStateHolder.state.value = RecorderState.Saving
        notifications.updateRecording(RecorderState.Saving)

        val rec = recorder
        val out = output
        recorder = null
        output = null
        audio = null

        scope.launch {
            val ok = withContext(Dispatchers.IO) {
                try {
                    rec?.stop() ?: false
                } catch (e: Exception) {
                    Log.e(TAG, "stop failed", e)
                    false
                }
            }
            val result = withContext(Dispatchers.IO) {
                out?.let { OutputFileManager.finalize(this@ScreenRecordService, it, ok) }
            }
            releaseProjection()
            if (result != null && result.success && out != null) {
                RecorderStateHolder.events.tryEmit(RecorderEvent.Saved(result.uri, out.displayName))
                notifications.showSaved(result.uri, out.displayName)
            } else {
                val error = if (interrupted) RecorderError.INTERRUPTED else RecorderError.EMPTY_RECORDING
                RecorderStateHolder.events.tryEmit(RecorderEvent.Failed(error))
                notifications.showError(error)
            }
            RecorderStateHolder.state.value = RecorderState.Idle
            stopping = false
            finishService()
        }
    }

    /** Reports an error, releases everything and stops the service. Never throws. */
    private fun fail(error: RecorderError) {
        Log.w(TAG, "fail: $error")
        cleanupSession()
        RecorderStateHolder.state.value = RecorderState.Idle
        RecorderStateHolder.events.tryEmit(RecorderEvent.Failed(error))
        notifications.showError(error)
        finishService()
    }

    private fun cleanupSession() {
        countdownJob?.cancel()
        countdownJob = null
        floating?.hideAll()
        TouchIndicatorManager.stop(this)
        unregisterScreenReceiver()
        stopShakeDetector()
        val rec = recorder
        recorder = null
        val ok = try {
            rec?.stop() ?: false
        } catch (_: Exception) {
            false
        }
        audio?.release()
        audio = null
        output?.let { OutputFileManager.finalize(this, it, ok) }
        output = null
        releaseProjection()
    }

    private fun releaseProjection() {
        val mp = projection ?: return
        projection = null
        try {
            mp.unregisterCallback(projectionCallback)
        } catch (_: Exception) {
        }
        try {
            mp.stop()
        } catch (_: Exception) {
        }
    }

    private fun finishService() {
        try {
            ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
        } catch (_: Exception) {
        }
        stopSelf()
    }

    // ---------------------------------------------------------------- misc

    private fun registerScreenReceiver() {
        if (screenReceiverRegistered) return
        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_SCREEN_OFF)
            addAction(Intent.ACTION_USER_PRESENT)
        }
        ContextCompat.registerReceiver(this, screenReceiver, filter, ContextCompat.RECEIVER_NOT_EXPORTED)
        screenReceiverRegistered = true
    }

    private fun stopShakeDetector() {
        shakeDetector?.stop()
        shakeDetector = null
    }

    private fun unregisterScreenReceiver() {
        if (!screenReceiverRegistered) return
        try {
            unregisterReceiver(screenReceiver)
        } catch (_: Exception) {
        }
        screenReceiverRegistered = false
    }

    private fun toast(text: String) {
        mainHandler.post { Toast.makeText(applicationContext, text, Toast.LENGTH_LONG).show() }
    }

    override fun onDestroy() {
        // Last-chance cleanup if the system destroys the service mid-recording.
        if (!stopping && (recorder != null || projection != null)) {
            cleanupSession()
            RecorderStateHolder.state.value = RecorderState.Idle
        } else if (!stopping) {
            TouchIndicatorManager.stop(this)
            floating?.hideAll()
        }
        if (!stopping && RecorderStateHolder.state.value !is RecorderState.Saving) {
            RecorderStateHolder.state.value = RecorderState.Idle
        }
        scope.cancel()
        super.onDestroy()
    }
}
