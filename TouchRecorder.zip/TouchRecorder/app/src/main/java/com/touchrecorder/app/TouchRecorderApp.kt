package com.touchrecorder.app

import android.app.Application
import androidx.appcompat.app.AppCompatDelegate
import androidx.preference.PreferenceManager
import com.touchrecorder.app.data.SettingsRepository
import com.touchrecorder.app.recording.RecorderStateHolder
import com.touchrecorder.app.service.RecorderNotifications
import com.touchrecorder.app.touch.TouchIndicatorManager

class TouchRecorderApp : Application() {
    override fun onCreate() {
        super.onCreate()
        PreferenceManager.setDefaultValues(this, R.xml.preferences, false)
        ThemeHelper.apply(SettingsRepository(this).load().theme)
        RecorderNotifications(this).createChannels()
        // If the process died while recording with system "Show taps" on, switch it back off.
        if (!RecorderStateHolder.isBusy) TouchIndicatorManager.restoreIfNeeded(this)
    }
}

object ThemeHelper {
    fun apply(theme: String) {
        AppCompatDelegate.setDefaultNightMode(
            when (theme) {
                "light" -> AppCompatDelegate.MODE_NIGHT_NO
                "dark" -> AppCompatDelegate.MODE_NIGHT_YES
                else -> AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM
            }
        )
    }
}
