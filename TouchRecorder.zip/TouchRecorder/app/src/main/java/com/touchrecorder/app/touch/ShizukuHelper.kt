package com.touchrecorder.app.touch

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.util.Log
import rikka.shizuku.Shizuku
import java.util.concurrent.TimeUnit

/**
 * Shizuku gives the app ADB ("shell") level access without a computer: the user installs the
 * Shizuku app and starts it once with Wireless debugging (Android 11+). With it the app can read
 * the raw touchscreen (/dev/input) and therefore show EVERY touch at its exact position.
 */
object ShizukuHelper {

    enum class Status { NOT_INSTALLED, NOT_RUNNING, NO_PERMISSION, READY, UNSUPPORTED }

    private const val TAG = "ShizukuHelper"
    const val PACKAGE = "moe.shizuku.privileged.api"
    const val REQUEST_CODE = 4711

    fun isInstalled(context: Context): Boolean =
        try {
            context.packageManager.getPackageInfo(PACKAGE, 0)
            true
        } catch (e: PackageManager.NameNotFoundException) {
            false
        }

    fun isRunning(): Boolean =
        try {
            Shizuku.pingBinder()
        } catch (e: Throwable) {
            false
        }

    fun status(context: Context): Status {
        if (!isRunning()) return if (isInstalled(context)) Status.NOT_RUNNING else Status.NOT_INSTALLED
        return try {
            when {
                Shizuku.isPreV11() -> Status.UNSUPPORTED
                Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED -> Status.READY
                else -> Status.NO_PERMISSION
            }
        } catch (e: Throwable) {
            Status.NOT_RUNNING
        }
    }

    fun isReady(context: Context): Boolean = status(context) == Status.READY

    /** Shows Shizuku's own permission dialog. Result arrives via [Shizuku.addRequestPermissionResultListener]. */
    fun requestPermission(): Boolean =
        try {
            if (Shizuku.shouldShowRequestPermissionRationale()) {
                false // user chose "deny and don't ask again" – must be changed inside Shizuku
            } else {
                Shizuku.requestPermission(REQUEST_CODE)
                true
            }
        } catch (e: Throwable) {
            Log.w(TAG, "requestPermission failed", e)
            false
        }

    fun openShizukuIntent(context: Context): Intent =
        context.packageManager.getLaunchIntentForPackage(PACKAGE)
            ?: Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=$PACKAGE"))

    fun storeIntent(): Intent =
        Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=$PACKAGE"))

    /**
     * Runs a shell command as the Shizuku (shell) user. Shizuku.newProcess is private in API 13,
     * so it is called through reflection – the approach recommended in the Shizuku issue tracker
     * for simple commands.
     */
    fun newProcess(vararg cmd: String): Process {
        val method = Shizuku::class.java.getDeclaredMethod(
            "newProcess",
            Array<String>::class.java,
            Array<String>::class.java,
            String::class.java
        )
        method.isAccessible = true
        return method.invoke(null, arrayOf(*cmd), null, null) as Process
    }

    /** Runs a short command and returns its stdout (or null on failure). */
    fun runForOutput(vararg cmd: String, timeoutMs: Long = 5000): String? =
        try {
            val p = newProcess(*cmd)
            val text = p.inputStream.bufferedReader().readText()
            p.waitFor(timeoutMs, TimeUnit.MILLISECONDS)
            p.destroy()
            text
        } catch (e: Throwable) {
            Log.w(TAG, "runForOutput failed: ${cmd.joinToString(" ")}", e)
            null
        }
}
