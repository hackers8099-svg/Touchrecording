package com.touchrecorder.app.ui

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.touchrecorder.app.data.RecordingItem
import com.touchrecorder.app.databinding.ItemRecordingBinding
import com.touchrecorder.app.util.Formatters

class RecordingsAdapter(
    private val loadThumbnail: (RecordingItem, ImageView) -> Unit,
    private val onClick: (RecordingItem) -> Unit,
    private val onMore: (RecordingItem, View) -> Unit
) : ListAdapter<RecordingItem, RecordingsAdapter.Holder>(Diff) {

    class Holder(val b: ItemRecordingBinding) : RecyclerView.ViewHolder(b.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Holder =
        Holder(ItemRecordingBinding.inflate(LayoutInflater.from(parent.context), parent, false))

    override fun onBindViewHolder(holder: Holder, position: Int) {
        val item = getItem(position)
        val ctx = holder.itemView.context
        with(holder.b) {
            name.text = item.name
            date.text = Formatters.date(item.dateAddedSec)
            size.text = Formatters.size(ctx, item.size)
            durationBadge.text = Formatters.elapsed(item.durationMs)
            durationBadge.visibility = if (item.durationMs > 0) View.VISIBLE else View.GONE
            loadThumbnail(item, thumbnail)
            root.setOnClickListener { onClick(item) }
            moreButton.setOnClickListener { onMore(item, it) }
        }
    }

    private object Diff : DiffUtil.ItemCallback<RecordingItem>() {
        override fun areItemsTheSame(oldItem: RecordingItem, newItem: RecordingItem) = oldItem.id == newItem.id
        override fun areContentsTheSame(oldItem: RecordingItem, newItem: RecordingItem) = oldItem == newItem
    }
}
