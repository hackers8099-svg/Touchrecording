package com.touchrecorder.app.data

import android.content.Context
import android.content.SharedPreferences
import android.graphics.Color
import androidx.preference.PreferenceManager

enum class AudioSource(val key: String) {
    NONE("none"), MIC("mic"), INTERNAL("internal"), BOTH("both");

    val usesMic: Boolean get() = this == MIC || this == BOTH
    val usesInternal: Boolean get() = this == INTERNAL || this == BOTH

    companion object {
        fun from(key: String?): AudioSource = entries.firstOrNull { it.key == key } ?: MIC
    }
}

enum class AudioQuality(val key: String, val sampleRate: Int, val bitrate: Int) {
    LOW("low", 44_100, 64_000),
    NORMAL("normal", 44_100, 128_000),
    HIGH("high", 48_000, 192_000);

    companion object {
        fun from(key: String?): AudioQuality = entries.firstOrNull { it.key == key } ?: NORMAL
    }
}

enum class OrientationMode(val key: String) {
    AUTO("auto"), PORTRAIT("portrait"), LANDSCAPE("landscape");

    companion object {
        fun from(key: String?): OrientationMode = entries.firstOrNull { it.key == key } ?: AUTO
    }
}

enum class TouchMode(val key: String) {
    AUTO("auto"), SYSTEM("system"), CUSTOM("custom");

    companion object {
        fun from(key: String?): TouchMode = entries.firstOrNull { it.key == key } ?: AUTO
    }
}

enum class TouchAnimation(val key: String) {
    RIPPLE("ripple"), RING("ring"), SPLASH("splash"), PULSE("pulse"), FADE("fade"), DOT("dot"), NONE("none");

    companion object {
        fun from(key: String?): TouchAnimation = entries.firstOrNull { it.key == key } ?: RIPPLE
    }
}

data class RecorderSettings(
    val resolution: String,
    val fps: Int,
    val bitrateMbps: Int?,
    val orientation: OrientationMode,
    val countdownSeconds: Int,
    val audioSource: AudioSource,
    val audioQuality: AudioQuality,
    val micVolume: Int,
    val internalVolume: Int,
    val showTouches: Boolean,
    val touchMode: TouchMode,
    val touchColor: Int,
    val touchSizeDp: Int,
    val touchOpacity: Int,
    val touchAnimation: TouchAnimation,
    val touchDurationMs: Int,
    val touchSound: Boolean,
    val floatingControls: Boolean,
    val pauseOnLock: Boolean,
    val shakeToStop: Boolean,
    val saveLocation: String,
    val filenameFormat: String,
    val theme: String,
    val language: String
) {
    /** Short side of the selected video size in pixels, or null for "Auto". */
    val shortSide: Int?
        get() = when (resolution) {
            "1080" -> 1080
            "720" -> 720
            "480" -> 480
            else -> null
        }
}

/**
 * Single source of truth for all user settings. The same SharedPreferences file is
 * edited by the PreferenceFragment in SettingsActivity.
 */
class SettingsRepository(context: Context) {

    private val prefs: SharedPreferences =
        PreferenceManager.getDefaultSharedPreferences(context.applicationContext)

    fun load(): RecorderSettings = RecorderSettings(
        resolution = prefs.getString(KEY_RESOLUTION, "auto") ?: "auto",
        fps = prefs.getString(KEY_FPS, "30")?.toIntOrNull()?.takeIf { it in listOf(24, 30, 60) } ?: 30,
        bitrateMbps = when (val b = prefs.getString(KEY_BITRATE, "auto")) {
            null, "auto" -> null
            "custom" -> (prefs.getString(KEY_BITRATE_CUSTOM, "10")?.toIntOrNull() ?: 10).coerceIn(1, 100)
            else -> b.toIntOrNull()
        },
        orientation = OrientationMode.from(prefs.getString(KEY_ORIENTATION, "auto")),
        countdownSeconds = prefs.getString(KEY_COUNTDOWN, "3")?.toIntOrNull()?.coerceIn(0, 10) ?: 3,
        audioSource = AudioSource.from(prefs.getString(KEY_AUDIO_SOURCE, AudioSource.MIC.key)),
        audioQuality = AudioQuality.from(prefs.getString(KEY_AUDIO_QUALITY, "normal")),
        micVolume = prefs.getInt(KEY_MIC_VOLUME, 100).coerceIn(0, 200),
        internalVolume = prefs.getInt(KEY_INTERNAL_VOLUME, 100).coerceIn(0, 200),
        showTouches = prefs.getBoolean(KEY_SHOW_TOUCHES, true),
        touchMode = TouchMode.from(prefs.getString(KEY_TOUCH_MODE, "auto")),
        touchColor = parseColor(prefs.getString(KEY_TOUCH_COLOR, "#FFFFFF")),
        touchSizeDp = prefs.getInt(KEY_TOUCH_SIZE, 48).coerceIn(16, 120),
        touchOpacity = prefs.getInt(KEY_TOUCH_OPACITY, 70).coerceIn(10, 100),
        touchAnimation = TouchAnimation.from(prefs.getString(KEY_TOUCH_ANIMATION, "ripple")),
        touchDurationMs = prefs.getInt(KEY_TOUCH_DURATION, 500).coerceIn(100, 3000),
        touchSound = prefs.getBoolean(KEY_TOUCH_SOUND, false),
        floatingControls = prefs.getBoolean(KEY_FLOATING, true),
        pauseOnLock = prefs.getBoolean(KEY_PAUSE_ON_LOCK, false),
        shakeToStop = prefs.getBoolean(KEY_SHAKE_TO_STOP, false),
        saveLocation = prefs.getString(KEY_SAVE_LOCATION, DEFAULT_SAVE_LOCATION)
            ?.takeIf { it in SAVE_LOCATIONS } ?: DEFAULT_SAVE_LOCATION,
        filenameFormat = prefs.getString(KEY_FILENAME, "touchrec") ?: "touchrec",
        theme = prefs.getString(KEY_THEME, "system") ?: "system",
        language = prefs.getString(KEY_LANGUAGE, "system") ?: "system"
    )

    fun setAudioSource(source: AudioSource) {
        prefs.edit().putString(KEY_AUDIO_SOURCE, source.key).apply()
    }

    private fun parseColor(value: String?): Int =
        try {
            Color.parseColor(value ?: "#FFFFFF")
        } catch (e: IllegalArgumentException) {
            Color.WHITE
        }

    companion object {
        const val KEY_RESOLUTION = "resolution"
        const val KEY_FPS = "fps"
        const val KEY_BITRATE = "bitrate"
        const val KEY_BITRATE_CUSTOM = "bitrate_custom"
        const val KEY_ORIENTATION = "orientation"
        const val KEY_COUNTDOWN = "countdown"
        const val KEY_AUDIO_SOURCE = "audio_source"
        const val KEY_AUDIO_QUALITY = "audio_quality"
        const val KEY_MIC_VOLUME = "mic_volume"
        const val KEY_INTERNAL_VOLUME = "internal_volume"
        const val KEY_SHOW_TOUCHES = "show_touches"
        const val KEY_TOUCH_MODE = "touch_mode"
        const val KEY_TOUCH_COLOR = "touch_color"
        const val KEY_TOUCH_SIZE = "touch_size"
        const val KEY_TOUCH_OPACITY = "touch_opacity"
        const val KEY_TOUCH_ANIMATION = "touch_animation"
        const val KEY_TOUCH_DURATION = "touch_duration"
        const val KEY_TOUCH_SOUND = "touch_sound"
        const val KEY_TOUCH_DEV_OPTIONS = "touch_dev_options"
        const val KEY_TOUCH_ACCESSIBILITY = "touch_accessibility"
        const val KEY_TOUCH_SYSTEM = "touch_system_adb"
        const val KEY_FLOATING = "floating_controls"
        const val KEY_OVERLAY_PERMISSION = "overlay_permission"
        const val KEY_PAUSE_ON_LOCK = "pause_on_lock"
        const val KEY_SHAKE_TO_STOP = "shake_to_stop"
        const val KEY_TOUCH_PREVIEW = "touch_preview"
        const val KEY_SAVE_LOCATION = "save_location"
        const val KEY_FILENAME = "filename_format"
        const val KEY_THEME = "theme"
        const val KEY_LANGUAGE = "language"
        const val KEY_VERSION = "version"

        const val DEFAULT_SAVE_LOCATION = "Movies/Screen Recordings"
        val SAVE_LOCATIONS = listOf(
            "Movies/Screen Recordings",
            "Movies/Touch Recorder",
            "DCIM/Screen Recordings"
        )
    }
}
