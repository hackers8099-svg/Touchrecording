package com.touchrecorder.app.recording

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.SystemClock
import kotlin.math.sqrt

/**
 * Calls [onShake] when the phone is shaken firmly (two strong jolts within ~0.6 s).
 * Uses only the accelerometer – no permission required. Ignores the first 2 s so the
 * movement of starting a recording doesn't stop it.
 */
class ShakeDetector(context: Context, private val onShake: () -> Unit) : SensorEventListener {

    private val sensorManager = context.getSystemService(SensorManager::class.java)
    private var startedAt = 0L
    private var firstJolt = 0L
    private var lastShake = 0L

    /** @return false when the device has no accelerometer. */
    fun start(): Boolean {
        val sensor = sensorManager?.getDefaultSensor(Sensor.TYPE_ACCELEROMETER) ?: return false
        startedAt = SystemClock.elapsedRealtime()
        return sensorManager.registerListener(this, sensor, SensorManager.SENSOR_DELAY_UI)
    }

    fun stop() {
        sensorManager?.unregisterListener(this)
    }

    override fun onSensorChanged(event: SensorEvent) {
        val now = SystemClock.elapsedRealtime()
        if (now - startedAt < 2000 || now - lastShake < 3000) return
        val x = event.values[0] / SensorManager.GRAVITY_EARTH
        val y = event.values[1] / SensorManager.GRAVITY_EARTH
        val z = event.values[2] / SensorManager.GRAVITY_EARTH
        val gForce = sqrt(x * x + y * y + z * z)
        if (gForce < THRESHOLD_G) return
        if (firstJolt == 0L || now - firstJolt > 600) {
            firstJolt = now
        } else if (now - firstJolt > 120) {
            firstJolt = 0L
            lastShake = now
            onShake()
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) = Unit

    companion object {
        private const val THRESHOLD_G = 2.5f
    }
}
