package com.touchrecorder.app.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.touchrecorder.app.R
import com.touchrecorder.app.permissions.PermissionManager
import com.touchrecorder.app.recording.RecorderError
import com.touchrecorder.app.recording.RecorderState
import com.touchrecorder.app.ui.MainActivity
import com.touchrecorder.app.ui.RecordingsActivity

class RecorderNotifications(private val context: Context) {

    private val manager = NotificationManagerCompat.from(context)

    fun createChannels() {
        val nm = context.getSystemService(NotificationManager::class.java) ?: return
        nm.createNotificationChannel(
            NotificationChannel(
                CHANNEL_RECORDING,
                context.getString(R.string.channel_recording),
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = context.getString(R.string.channel_recording_desc)
                setShowBadge(false)
            }
        )
        nm.createNotificationChannel(
            NotificationChannel(
                CHANNEL_RESULTS,
                context.getString(R.string.channel_results),
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply { description = context.getString(R.string.channel_results_desc) }
        )
    }

    fun buildRecording(state: RecorderState): Notification {
        val b = NotificationCompat.Builder(context, CHANNEL_RECORDING)
            .setSmallIcon(R.drawable.ic_stat_record)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setSilent(true)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setForegroundServiceBehavior(NotificationCompat.FOREGROUND_SERVICE_IMMEDIATE)
            .setContentIntent(openAppIntent())

        when (state) {
            is RecorderState.Countdown -> {
                b.setContentTitle(context.getString(R.string.notif_recording_title))
                b.setContentText(context.getString(R.string.notif_countdown, state.secondsLeft))
                b.addAction(R.drawable.ic_stop, context.getString(R.string.stop), serviceIntent(ScreenRecordService.ACTION_STOP))
            }
            is RecorderState.Recording -> {
                b.setContentTitle(context.getString(R.string.notif_recording_title))
                if (state.isPaused) {
                    b.setContentText(context.getString(R.string.notif_paused_text))
                    b.setShowWhen(false)
                    b.addAction(R.drawable.ic_play, context.getString(R.string.resume), serviceIntent(ScreenRecordService.ACTION_RESUME))
                } else {
                    b.setContentText(context.getString(R.string.notif_recording_text))
                    b.setUsesChronometer(true)
                    b.setShowWhen(true)
                    b.setWhen(System.currentTimeMillis() - state.elapsedMs())
                    b.addAction(R.drawable.ic_pause, context.getString(R.string.pause), serviceIntent(ScreenRecordService.ACTION_PAUSE))
                }
                b.addAction(R.drawable.ic_stop, context.getString(R.string.stop), serviceIntent(ScreenRecordService.ACTION_STOP))
            }
            is RecorderState.Saving -> {
                b.setContentTitle(context.getString(R.string.notif_saving))
                b.setProgress(0, 0, true)
            }
            else -> b.setContentTitle(context.getString(R.string.notif_preparing))
        }
        return b.build()
    }

    fun updateRecording(state: RecorderState) {
        notifySafe(ID_RECORDING, buildRecording(state))
    }

    fun showSaved(uri: Uri?, name: String) {
        val intent = if (uri != null) {
            Intent(Intent.ACTION_VIEW).setDataAndType(uri, "video/mp4")
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        } else {
            Intent(context, RecordingsActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        val pi = PendingIntent.getActivity(
            context, 2, intent, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val library = PendingIntent.getActivity(
            context, 3,
            Intent(context, RecordingsActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = NotificationCompat.Builder(context, CHANNEL_RESULTS)
            .setSmallIcon(R.drawable.ic_stat_record)
            .setContentTitle(context.getString(R.string.notif_saved_title))
            .setContentText(context.getString(R.string.notif_saved_text, name))
            .setAutoCancel(true)
            .setContentIntent(pi)
            .addAction(R.drawable.ic_video_library, context.getString(R.string.recordings), library)
            .build()
        notifySafe(ID_RESULT, n)
    }

    fun showError(error: RecorderError) {
        val text = context.getString(error.messageRes)
        val n = NotificationCompat.Builder(context, CHANNEL_RESULTS)
            .setSmallIcon(R.drawable.ic_stat_record)
            .setContentTitle(context.getString(R.string.notif_error_title))
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setAutoCancel(true)
            .setContentIntent(openAppIntent())
            .build()
        notifySafe(ID_RESULT, n)
    }

    private fun notifySafe(id: Int, notification: Notification) {
        if (!PermissionManager.hasNotifications(context)) return
        try {
            manager.notify(id, notification)
        } catch (_: SecurityException) {
        }
    }

    private fun openAppIntent(): PendingIntent = PendingIntent.getActivity(
        context, 0,
        Intent(context, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_NEW_TASK),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    )

    private fun serviceIntent(action: String): PendingIntent = PendingIntent.getService(
        context, action.hashCode(),
        Intent(context, ScreenRecordService::class.java).setAction(action),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    )

    companion object {
        const val CHANNEL_RECORDING = "recording"
        const val CHANNEL_RESULTS = "results"
        const val ID_RECORDING = 1001
        const val ID_RESULT = 1002
    }
}
