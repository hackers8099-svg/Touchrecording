package com.touchrecorder.app.recording

import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionConfig
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.util.Log

/**
 * Thin wrapper around the system [MediaProjectionManager] (named ProjectionManager to avoid
 * clashing with the framework class).
 *
 * Android 14+: a consent result can be used exactly once, and the projection must be obtained
 * from a foreground service of type "mediaProjection" — ScreenRecordService does both.
 */
class ProjectionManager(context: Context) {

    private val system: MediaProjectionManager? =
        context.getSystemService(MediaProjectionManager::class.java)

    /** System consent dialog. On Android 14+ we ask for the whole screen so touches are captured. */
    fun createConsentIntent(): Intent? {
        val mpm = system ?: return null
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            mpm.createScreenCaptureIntent(MediaProjectionConfig.createConfigForDefaultDisplay())
        } else {
            mpm.createScreenCaptureIntent()
        }
    }

    fun obtain(resultCode: Int, data: Intent): MediaProjection? =
        try {
            system?.getMediaProjection(resultCode, data)
        } catch (e: Exception) {
            Log.e("ProjectionManager", "getMediaProjection failed", e)
            null
        }
}
