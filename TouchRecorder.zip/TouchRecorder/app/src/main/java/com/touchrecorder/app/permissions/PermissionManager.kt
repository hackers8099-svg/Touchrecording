package com.touchrecorder.app.permissions

import android.Manifest
import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.core.content.ContextCompat
import com.touchrecorder.app.BuildConfig
import com.touchrecorder.app.data.AudioSource
import com.touchrecorder.app.data.RecorderSettings

/**
 * Central place for every permission check. Only permissions that the current settings
 * actually need are requested.
 */
object PermissionManager {

    val ADB_GRANT_COMMAND: String =
        "adb shell pm grant ${BuildConfig.APPLICATION_ID} android.permission.WRITE_SECURE_SETTINGS"

    private fun granted(context: Context, permission: String): Boolean =
        ContextCompat.checkSelfPermission(context, permission) == PackageManager.PERMISSION_GRANTED

    fun hasMic(context: Context): Boolean = granted(context, Manifest.permission.RECORD_AUDIO)

    fun hasNotifications(context: Context): Boolean =
        Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU ||
            granted(context, Manifest.permission.POST_NOTIFICATIONS)

    fun canDrawOverlays(context: Context): Boolean = Settings.canDrawOverlays(context)

    /** Android 8/9 need WRITE_EXTERNAL_STORAGE to save into Movies/. */
    fun hasLegacyStorage(context: Context): Boolean =
        Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q ||
            granted(context, Manifest.permission.WRITE_EXTERNAL_STORAGE)

    fun videoReadPermission(): String =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) Manifest.permission.READ_MEDIA_VIDEO
        else Manifest.permission.READ_EXTERNAL_STORAGE

    fun hasVideoRead(context: Context): Boolean = granted(context, videoReadPermission())

    fun hasSecureSettings(context: Context): Boolean =
        granted(context, Manifest.permission.WRITE_SECURE_SETTINGS)

    /** Runtime permissions required to start a recording with [settings]. */
    fun runtimePermissionsFor(context: Context, settings: RecorderSettings): List<String> {
        val list = ArrayList<String>()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU && !hasNotifications(context)) {
            list.add(Manifest.permission.POST_NOTIFICATIONS)
        }
        if (settings.audioSource != AudioSource.NONE && !hasMic(context)) {
            list.add(Manifest.permission.RECORD_AUDIO)
        }
        if (!hasLegacyStorage(context)) {
            list.add(Manifest.permission.WRITE_EXTERNAL_STORAGE)
        }
        return list
    }

    fun appSettingsIntent(context: Context): Intent =
        Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.fromParts("package", context.packageName, null))

    fun overlaySettingsIntent(context: Context): Intent =
        Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${context.packageName}"))

    fun accessibilitySettingsIntent(): Intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)

    fun developerOptionsIntent(): Intent = Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS)

    /** Starts [intent] and falls back to the app details page; never throws. */
    fun safeStart(activity: Activity, intent: Intent): Boolean =
        try {
            activity.startActivity(intent)
            true
        } catch (e: ActivityNotFoundException) {
            try {
                activity.startActivity(appSettingsIntent(activity))
                true
            } catch (_: Exception) {
                false
            }
        } catch (_: SecurityException) {
            false
        }
}
