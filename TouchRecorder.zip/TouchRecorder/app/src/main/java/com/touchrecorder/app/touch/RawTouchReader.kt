package com.touchrecorder.app.touch

import android.os.Build
import android.util.Log
import java.io.DataInputStream
import java.io.EOFException
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.concurrent.thread

/**
 * Reads the raw touchscreen through Shizuku and reports every finger with its exact position.
 *
 * 1. `getevent -lp` lists input devices; the one reporting ABS_MT_POSITION_X/Y is the
 *    touchscreen, and its min/max values are used to normalise coordinates to 0..1.
 * 2. `cat /dev/input/eventN` streams binary `struct input_event` records without buffering.
 *    Multi-touch protocol B (slots + tracking IDs) is decoded into down / move / up events.
 *
 * Coordinates are delivered normalised (0..1) in the panel's natural orientation; the caller maps
 * them to the current screen rotation.
 */
class RawTouchReader(private val listener: Listener) {

    interface Listener {
        fun onDown(pointer: Int, nx: Float, ny: Float)
        fun onMove(pointer: Int, nx: Float, ny: Float)
        fun onUp(pointer: Int)
    }

    data class Device(val path: String, val minX: Int, val maxX: Int, val minY: Int, val maxY: Int, val multiTouch: Boolean)

    @Volatile
    private var process: Process? = null

    @Volatile
    private var running = false
    private var worker: Thread? = null

    /** @return false if no touchscreen could be found or the process couldn't start. */
    fun start(): Boolean {
        val device = findTouchscreen() ?: return false
        val p = try {
            ShizukuHelper.newProcess("cat", device.path)
        } catch (e: Throwable) {
            Log.e(TAG, "cannot start reader", e)
            return false
        }
        process = p
        running = true
        worker = thread(name = "TR-touch", isDaemon = true) { loop(p, device) }
        return true
    }

    fun stop() {
        running = false
        try {
            process?.destroy()
        } catch (_: Throwable) {
        }
        process = null
        worker?.interrupt()
        worker = null
    }

    private fun loop(p: Process, d: Device) {
        val eventSize = if (Build.SUPPORTED_64_BIT_ABIS.isNotEmpty()) 24 else 16
        val timeSize = eventSize - 8
        val input = DataInputStream(p.inputStream.buffered(eventSize * 64))
        val raw = ByteArray(eventSize)
        val buf = ByteBuffer.wrap(raw).order(ByteOrder.nativeOrder())

        val slots = 10
        val tracking = IntArray(slots) { -1 }
        val xs = IntArray(slots) { Int.MIN_VALUE }
        val ys = IntArray(slots) { Int.MIN_VALUE }
        val downPending = BooleanArray(slots)
        val moved = BooleanArray(slots)
        val upPending = BooleanArray(slots)
        val lastMoveAt = LongArray(slots)
        var slot = 0
        var touching = false // single-touch fallback (BTN_TOUCH)

        fun nx(x: Int) = ((x - d.minX).toFloat() / (d.maxX - d.minX).coerceAtLeast(1)).coerceIn(0f, 1f)
        fun ny(y: Int) = ((y - d.minY).toFloat() / (d.maxY - d.minY).coerceAtLeast(1)).coerceIn(0f, 1f)

        try {
            while (running) {
                input.readFully(raw)
                val type = buf.getShort(timeSize).toInt() and 0xFFFF
                val code = buf.getShort(timeSize + 2).toInt() and 0xFFFF
                val value = buf.getInt(timeSize + 4)
                when (type) {
                    EV_ABS -> when (code) {
                        ABS_MT_SLOT -> slot = value.coerceIn(0, slots - 1)
                        ABS_MT_TRACKING_ID -> if (value < 0) {
                            if (tracking[slot] >= 0) upPending[slot] = true
                            tracking[slot] = -1
                        } else {
                            tracking[slot] = value
                            downPending[slot] = true
                            upPending[slot] = false
                        }
                        ABS_MT_POSITION_X -> { xs[slot] = value; moved[slot] = true }
                        ABS_MT_POSITION_Y -> { ys[slot] = value; moved[slot] = true }
                        ABS_X -> if (!d.multiTouch) { xs[0] = value; moved[0] = true }
                        ABS_Y -> if (!d.multiTouch) { ys[0] = value; moved[0] = true }
                    }
                    EV_KEY -> if (code == BTN_TOUCH && !d.multiTouch) {
                        if (value == 1 && !touching) { touching = true; downPending[0] = true }
                        if (value == 0 && touching) { touching = false; upPending[0] = true }
                    }
                    EV_SYN -> if (code == SYN_REPORT) {
                        val now = System.nanoTime() / 1_000_000
                        for (i in 0 until slots) {
                            val hasPos = xs[i] != Int.MIN_VALUE && ys[i] != Int.MIN_VALUE
                            if (downPending[i] && hasPos) {
                                listener.onDown(i, nx(xs[i]), ny(ys[i]))
                                downPending[i] = false
                                lastMoveAt[i] = now
                            } else if (moved[i] && hasPos && (tracking[i] >= 0 || touching) &&
                                now - lastMoveAt[i] >= 12
                            ) {
                                listener.onMove(i, nx(xs[i]), ny(ys[i]))
                                lastMoveAt[i] = now
                            }
                            if (upPending[i]) {
                                listener.onUp(i)
                                upPending[i] = false
                                downPending[i] = false
                            }
                            moved[i] = false
                        }
                    }
                }
            }
        } catch (e: EOFException) {
            // process ended
        } catch (e: Throwable) {
            if (running) Log.w(TAG, "touch reader stopped", e)
        }
    }

    companion object {
        private const val TAG = "RawTouchReader"
        private const val EV_SYN = 0
        private const val EV_KEY = 1
        private const val EV_ABS = 3
        private const val SYN_REPORT = 0
        private const val BTN_TOUCH = 0x14a
        private const val ABS_X = 0x00
        private const val ABS_Y = 0x01
        private const val ABS_MT_SLOT = 0x2f
        private const val ABS_MT_POSITION_X = 0x35
        private const val ABS_MT_POSITION_Y = 0x36
        private const val ABS_MT_TRACKING_ID = 0x39

        private val DEVICE_LINE = Regex("""add device \d+:\s*(\S+)""")
        private val NAME_LINE = Regex("""name:\s*"(.*)"""")

        private fun axis(block: String, name: String): Pair<Int, Int>? {
            val m = Regex("""\b$name\s*:\s*value\s*-?\d+,\s*min\s*(-?\d+),\s*max\s*(-?\d+)""").find(block)
                ?: return null
            return m.groupValues[1].toInt() to m.groupValues[2].toInt()
        }

        /** Parses `getevent -lp` and returns the touchscreen (prefers names containing "touch"). */
        fun findTouchscreen(): Device? {
            val out = ShizukuHelper.runForOutput("getevent", "-lp") ?: return null
            val starts = DEVICE_LINE.findAll(out).toList()
            val candidates = ArrayList<Pair<Device, String>>()
            for ((i, m) in starts.withIndex()) {
                val end = if (i + 1 < starts.size) starts[i + 1].range.first else out.length
                val block = out.substring(m.range.first, end)
                val path = m.groupValues[1]
                val name = NAME_LINE.find(block)?.groupValues?.get(1) ?: ""
                val mtX = axis(block, "ABS_MT_POSITION_X")
                val mtY = axis(block, "ABS_MT_POSITION_Y")
                val device = if (mtX != null && mtY != null) {
                    Device(path, mtX.first, mtX.second, mtY.first, mtY.second, multiTouch = true)
                } else {
                    val x = axis(block, "ABS_X")
                    val y = axis(block, "ABS_Y")
                    if (x != null && y != null && block.contains("BTN_TOUCH")) {
                        Device(path, x.first, x.second, y.first, y.second, multiTouch = false)
                    } else null
                }
                if (device != null && device.maxX > device.minX && device.maxY > device.minY) {
                    candidates.add(device to name.lowercase())
                }
            }
            return (candidates.firstOrNull { it.second.contains("touch") } ?: candidates.firstOrNull())?.first
        }
    }
}
