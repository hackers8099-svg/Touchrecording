package com.touchrecorder.app.ui

import android.content.ActivityNotFoundException
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.provider.DocumentsContract
import android.text.InputType
import android.util.LruCache
import android.view.LayoutInflater
import android.view.View
import android.widget.EditText
import android.widget.ImageView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.PopupMenu
import androidx.core.view.isVisible
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.textfield.TextInputLayout
import com.touchrecorder.app.R
import com.touchrecorder.app.data.RecordingItem
import com.touchrecorder.app.data.RecordingsRepository
import com.touchrecorder.app.data.WriteResult
import com.touchrecorder.app.databinding.ActivityRecordingsBinding
import com.touchrecorder.app.permissions.PermissionManager
import com.touchrecorder.app.recording.RecorderEvent
import com.touchrecorder.app.recording.RecorderStateHolder
import com.touchrecorder.app.util.applySystemBarPadding
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class RecordingsActivity : AppCompatActivity() {

    private lateinit var b: ActivityRecordingsBinding
    private lateinit var repo: RecordingsRepository
    private lateinit var adapter: RecordingsAdapter
    private val thumbs = LruCache<Long, Bitmap>(80)
    private var pendingRetry: (() -> Unit)? = null

    private val writeRequest =
        registerForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { result ->
            val retry = pendingRetry
            pendingRetry = null
            if (result.resultCode == RESULT_OK) retry?.invoke()
            reload()
        }

    private val readPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { reload() }

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        b = ActivityRecordingsBinding.inflate(layoutInflater)
        setContentView(b.root)
        setSupportActionBar(b.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        b.toolbar.setNavigationOnClickListener { finish() }

        repo = RecordingsRepository(this)
        adapter = RecordingsAdapter(::loadThumbnail, ::play) { item, anchor -> showMenu(item, anchor) }
        b.recycler.layoutManager = LinearLayoutManager(this)
        b.recycler.adapter = adapter
        b.recycler.applySystemBarPadding(top = false, bottom = true)
        b.swipeRefresh.setOnRefreshListener { reload() }
        b.bannerButton.setOnClickListener { readPermission.launch(PermissionManager.videoReadPermission()) }

        lifecycleScope.launch {
            RecorderStateHolder.events.collect { if (it is RecorderEvent.Saved) reload() }
        }
    }

    override fun onResume() {
        super.onResume()
        reload()
    }

    private fun reload() {
        b.swipeRefresh.isRefreshing = true
        lifecycleScope.launch {
            val items = withContext(Dispatchers.IO) { repo.query() }
            adapter.submitList(items)
            b.emptyView.isVisible = items.isEmpty()
            b.bannerCard.isVisible = !PermissionManager.hasVideoRead(this@RecordingsActivity)
            b.swipeRefresh.isRefreshing = false
        }
    }

    private fun loadThumbnail(item: RecordingItem, view: ImageView) {
        view.tag = item.id
        val cached = thumbs.get(item.id)
        if (cached != null) {
            view.setImageBitmap(cached)
            return
        }
        view.setImageResource(R.drawable.ic_video_library)
        lifecycleScope.launch {
            val bmp = withContext(Dispatchers.IO) { repo.thumbnail(item) }
            if (bmp != null) thumbs.put(item.id, bmp)
            if (view.tag == item.id && bmp != null) view.setImageBitmap(bmp)
        }
    }

    private fun showMenu(item: RecordingItem, anchor: View) {
        PopupMenu(this, anchor).apply {
            menuInflater.inflate(R.menu.recording_item, menu)
            setOnMenuItemClickListener { mi ->
                when (mi.itemId) {
                    R.id.action_play -> play(item)
                    R.id.action_share -> share(item)
                    R.id.action_rename -> rename(item)
                    R.id.action_delete -> confirmDelete(item)
                    R.id.action_open_folder -> openFolder(item)
                }
                true
            }
            show()
        }
    }

    private fun play(item: RecordingItem) {
        try {
            startActivity(
                Intent(Intent.ACTION_VIEW).setDataAndType(item.uri, "video/mp4")
                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            )
        } catch (e: ActivityNotFoundException) {
            toast(R.string.no_player)
        }
    }

    private fun share(item: RecordingItem) {
        val send = Intent(Intent.ACTION_SEND)
            .setType("video/mp4")
            .putExtra(Intent.EXTRA_STREAM, item.uri)
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        try {
            startActivity(Intent.createChooser(send, getString(R.string.share_title)))
        } catch (e: ActivityNotFoundException) {
            toast(R.string.action_failed)
        }
    }

    private fun rename(item: RecordingItem) {
        val layout = LayoutInflater.from(this).inflate(R.layout.dialog_rename, null) as TextInputLayout
        val edit = layout.editText as EditText
        edit.inputType = InputType.TYPE_CLASS_TEXT
        edit.setText(item.name.removeSuffix(".mp4"))
        edit.setSelection(edit.text.length)
        MaterialAlertDialogBuilder(this)
            .setTitle(R.string.rename_title)
            .setView(layout)
            .setPositiveButton(R.string.btn_ok) { _, _ ->
                val newName = edit.text.toString()
                if (newName.isBlank()) {
                    toast(R.string.rename_invalid)
                    return@setPositiveButton
                }
                runWrite({ repo.rename(item, newName) }, R.string.renamed)
            }
            .setNegativeButton(R.string.btn_cancel, null)
            .show()
    }

    private fun confirmDelete(item: RecordingItem) {
        MaterialAlertDialogBuilder(this)
            .setTitle(R.string.delete_title)
            .setMessage(getString(R.string.delete_message, item.name))
            .setPositiveButton(R.string.menu_delete) { _, _ -> runWrite({ repo.delete(item) }, R.string.deleted) }
            .setNegativeButton(R.string.btn_cancel, null)
            .show()
    }

    /** Runs a MediaStore write, asking the system for consent when the file isn't ours. */
    private fun runWrite(action: () -> WriteResult, successMessage: Int) {
        lifecycleScope.launch {
            when (val r = withContext(Dispatchers.IO) { action() }) {
                WriteResult.Done -> {
                    toast(successMessage)
                    reload()
                }
                WriteResult.Failed -> toast(R.string.action_failed)
                is WriteResult.NeedsPermission -> {
                    val retry: () -> Unit = { runWrite(action, successMessage) }
                    pendingRetry = if (r.retryAfter) retry else null
                    try {
                        writeRequest.launch(IntentSenderRequest.Builder(r.sender).build())
                    } catch (e: Exception) {
                        pendingRetry = null
                        toast(R.string.action_failed)
                    }
                }
            }
        }
    }

    private fun openFolder(item: RecordingItem) {
        val docId = "primary:" + item.relativeDir
        val folderUri: Uri = DocumentsContract.buildDocumentUri(EXTERNAL_STORAGE_AUTHORITY, docId)
        val attempts = listOf(
            Intent(Intent.ACTION_VIEW).setDataAndType(folderUri, DocumentsContract.Document.MIME_TYPE_DIR),
            Intent(Intent.ACTION_VIEW).setDataAndType(folderUri, "vnd.android.document/root"),
            Intent(Intent.ACTION_VIEW).setDataAndType(folderUri, "resource/folder")
        )
        for (intent in attempts) {
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            try {
                startActivity(intent)
                return
            } catch (_: ActivityNotFoundException) {
            } catch (_: SecurityException) {
            }
        }
        Toast.makeText(this, getString(R.string.no_file_manager, item.relativeDir), Toast.LENGTH_LONG).show()
    }

    private fun toast(res: Int) = Toast.makeText(this, res, Toast.LENGTH_SHORT).show()

    companion object {
        private const val EXTERNAL_STORAGE_AUTHORITY = "com.android.externalstorage.documents"
    }
}
