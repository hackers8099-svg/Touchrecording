package com.touchrecorder.app.touch

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.os.SystemClock
import android.util.AttributeSet
import android.view.View
import com.touchrecorder.app.data.TouchAnimation
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.sin

/**
 * Draws animated touch indicators. Used full-screen by the accessibility service (Pro edition)
 * and inside the live preview on the settings screen.
 */
class TouchOverlayView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    private class Dot(val x: Float, val y: Float, val start: Long)

    /** A finger that is still on the screen (exact mode): follows the finger and leaves a trail. */
    private class Held(var x: Float, var y: Float) {
        val trailX = FloatArray(TRAIL)
        val trailY = FloatArray(TRAIL)
        val trailT = LongArray(TRAIL)
        var count = 0
        var head = 0

        fun add(x: Float, y: Float, t: Long) {
            trailX[head] = x; trailY[head] = y; trailT[head] = t
            head = (head + 1) % TRAIL
            if (count < TRAIL) count++
        }
    }

    private val dots = ArrayList<Dot>()
    private val held = HashMap<Int, Held>()
    private val location = IntArray(2)
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }

    var touchStyle: TouchStyle? = null

    /** [screenX]/[screenY] are absolute screen coordinates. */
    fun showTouch(screenX: Float, screenY: Float) {
        getLocationOnScreen(location)
        dots.add(Dot(screenX - location[0], screenY - location[1], SystemClock.uptimeMillis()))
        if (dots.size > 24) dots.removeAt(0)
        postInvalidateOnAnimation()
    }

    /** Exact mode: a finger went down at absolute screen coordinates. */
    fun pointerDown(id: Int, screenX: Float, screenY: Float) {
        showTouch(screenX, screenY)
        getLocationOnScreen(location)
        val x = screenX - location[0]
        val y = screenY - location[1]
        held[id] = Held(x, y).also { it.add(x, y, SystemClock.uptimeMillis()) }
        postInvalidateOnAnimation()
    }

    fun pointerMove(id: Int, screenX: Float, screenY: Float) {
        val h = held[id] ?: return
        getLocationOnScreen(location)
        h.x = screenX - location[0]
        h.y = screenY - location[1]
        h.add(h.x, h.y, SystemClock.uptimeMillis())
        postInvalidateOnAnimation()
    }

    fun pointerUp(id: Int) {
        held.remove(id)
        postInvalidateOnAnimation()
    }

    fun clear() {
        dots.clear()
        held.clear()
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val s = touchStyle ?: return
        val now = SystemClock.uptimeMillis()
        val iterator = dots.iterator()
        while (iterator.hasNext()) {
            val d = iterator.next()
            val p = (now - d.start).toFloat() / s.durationMs.coerceAtLeast(1)
            if (p >= 1f) {
                iterator.remove()
                continue
            }
            draw(canvas, s, d.x, d.y, p)
        }
        for (h in held.values) drawHeld(canvas, s, h, now)
        if (dots.isNotEmpty() || held.isNotEmpty()) postInvalidateOnAnimation()
    }

    /** Swipe trail + a soft circle under the finger while it is held down. */
    private fun drawHeld(c: Canvas, s: TouchStyle, h: Held, now: Long) {
        val a = s.alpha.toFloat()
        if (h.count > 1) {
            var prev = -1
            for (k in 0 until h.count) {
                val i = (h.head - h.count + k + TRAIL) % TRAIL
                val age = now - h.trailT[i]
                if (age > TRAIL_MS) continue
                if (prev >= 0) {
                    val f = 1f - age.toFloat() / TRAIL_MS
                    stroke.color = s.color
                    stroke.alpha = (a * 0.6f * f).toInt().coerceIn(0, 255)
                    stroke.strokeWidth = max(3f, s.radiusPx * 0.45f * f)
                    c.drawLine(h.trailX[prev], h.trailY[prev], h.trailX[i], h.trailY[i], stroke)
                }
                prev = i
            }
        }
        if (s.animation != TouchAnimation.DOT) {
            fill.color = s.color
            fill.alpha = (a * 0.45f).toInt().coerceIn(0, 255)
            c.drawCircle(h.x, h.y, s.radiusPx * 0.6f, fill)
        } else {
            fill.color = s.color
            fill.alpha = s.alpha
            c.drawCircle(h.x, h.y, s.radiusPx * 0.45f, fill)
        }
    }

    private fun draw(c: Canvas, s: TouchStyle, x: Float, y: Float, p: Float) {
        val r = s.radiusPx
        val a = s.alpha.toFloat()
        val outline = if (s.color == Color.WHITE) Color.DKGRAY else Color.WHITE
        fun fillPaint(alpha: Float) = fill.apply { color = s.color; this.alpha = alpha.toInt().coerceIn(0, 255) }
        fun strokePaint(col: Int, alpha: Float, width: Float) = stroke.apply {
            color = col; this.alpha = alpha.toInt().coerceIn(0, 255); strokeWidth = max(2f, width)
        }
        // Fade out over the last 30 % of the duration.
        val tail = if (p > 0.7f) (1f - p) / 0.3f else 1f

        when (s.animation) {
            TouchAnimation.RIPPLE -> {
                // Filled circle that grows and fades, with a thin rim.
                val rr = r * (0.55f + 0.65f * p)
                c.drawCircle(x, y, rr, fillPaint(a * (1f - p)))
                c.drawCircle(x, y, rr, strokePaint(outline, a * 0.8f * (1f - p), r * 0.07f))
            }
            TouchAnimation.RING -> {
                // Two outline rings expanding one after the other + a small center dot.
                for (k in 0..1) {
                    val q = ((p - k * 0.25f) / 0.75f).coerceIn(0f, 1f)
                    if (q <= 0f) continue
                    c.drawCircle(x, y, r * (0.3f + 0.9f * q), strokePaint(s.color, a * (1f - q), r * 0.12f))
                }
                c.drawCircle(x, y, r * 0.22f, fillPaint(a * tail))
            }
            TouchAnimation.SPLASH -> {
                // Center dot with 8 rays bursting outwards.
                c.drawCircle(x, y, r * 0.35f * (1f - 0.4f * p), fillPaint(a * tail))
                val inner = r * (0.45f + 0.6f * p)
                val outer = inner + r * 0.35f * (1f - p)
                val paint = strokePaint(s.color, a * (1f - p), r * 0.1f)
                for (i in 0 until 8) {
                    val ang = (i * PI / 4).toFloat()
                    c.drawLine(
                        x + cos(ang) * inner, y + sin(ang) * inner,
                        x + cos(ang) * outer, y + sin(ang) * outer, paint
                    )
                }
            }
            TouchAnimation.PULSE -> {
                val rr = r * (1f + 0.25f * sin(p * PI * 2).toFloat().coerceAtLeast(0f))
                c.drawCircle(x, y, rr, fillPaint(a * tail))
                c.drawCircle(x, y, rr, strokePaint(outline, a * 0.8f * tail, r * 0.07f))
            }
            TouchAnimation.FADE -> {
                c.drawCircle(x, y, r, fillPaint(a * (1f - p)))
                c.drawCircle(x, y, r, strokePaint(outline, a * 0.8f * (1f - p), r * 0.07f))
            }
            TouchAnimation.DOT -> {
                // Small solid fingertip dot, like a presentation pointer.
                c.drawCircle(x, y, r * 0.45f, fillPaint(a * tail))
                c.drawCircle(x, y, r * 0.45f, strokePaint(outline, a * tail, r * 0.06f))
            }
            TouchAnimation.NONE -> {
                c.drawCircle(x, y, r, fillPaint(a))
                c.drawCircle(x, y, r, strokePaint(outline, a * 0.8f, r * 0.07f))
            }
        }
    }

    private companion object {
        const val TRAIL = 32
        const val TRAIL_MS = 220L
    }
}
