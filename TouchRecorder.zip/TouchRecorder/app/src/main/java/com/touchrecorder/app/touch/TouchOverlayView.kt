package com.touchrecorder.app.touch

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.os.SystemClock
import android.util.AttributeSet
import android.view.View
import com.touchrecorder.app.data.TouchAnimation
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.sin

/**
 * Draws animated touch indicators. Used full-screen by the accessibility service (Pro edition)
 * and inside the live preview on the settings screen.
 */
class TouchOverlayView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    private class Dot(val x: Float, val y: Float, val start: Long)

    private val dots = ArrayList<Dot>()
    private val location = IntArray(2)
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }

    var touchStyle: TouchStyle? = null

    /** [screenX]/[screenY] are absolute screen coordinates. */
    fun showTouch(screenX: Float, screenY: Float) {
        getLocationOnScreen(location)
        dots.add(Dot(screenX - location[0], screenY - location[1], SystemClock.uptimeMillis()))
        if (dots.size > 24) dots.removeAt(0)
        postInvalidateOnAnimation()
    }

    fun clear() {
        dots.clear()
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val s = touchStyle ?: return
        val now = SystemClock.uptimeMillis()
        val iterator = dots.iterator()
        while (iterator.hasNext()) {
            val d = iterator.next()
            val p = (now - d.start).toFloat() / s.durationMs.coerceAtLeast(1)
            if (p >= 1f) {
                iterator.remove()
                continue
            }
            draw(canvas, s, d.x, d.y, p)
        }
        if (dots.isNotEmpty()) postInvalidateOnAnimation()
    }

    private fun draw(c: Canvas, s: TouchStyle, x: Float, y: Float, p: Float) {
        val r = s.radiusPx
        val a = s.alpha.toFloat()
        val outline = if (s.color == Color.WHITE) Color.DKGRAY else Color.WHITE
        fun fillPaint(alpha: Float) = fill.apply { color = s.color; this.alpha = alpha.toInt().coerceIn(0, 255) }
        fun strokePaint(col: Int, alpha: Float, width: Float) = stroke.apply {
            color = col; this.alpha = alpha.toInt().coerceIn(0, 255); strokeWidth = max(2f, width)
        }
        // Fade out over the last 30 % of the duration.
        val tail = if (p > 0.7f) (1f - p) / 0.3f else 1f

        when (s.animation) {
            TouchAnimation.RIPPLE -> {
                // Filled circle that grows and fades, with a thin rim.
                val rr = r * (0.55f + 0.65f * p)
                c.drawCircle(x, y, rr, fillPaint(a * (1f - p)))
                c.drawCircle(x, y, rr, strokePaint(outline, a * 0.8f * (1f - p), r * 0.07f))
            }
            TouchAnimation.RING -> {
                // Two outline rings expanding one after the other + a small center dot.
                for (k in 0..1) {
                    val q = ((p - k * 0.25f) / 0.75f).coerceIn(0f, 1f)
                    if (q <= 0f) continue
                    c.drawCircle(x, y, r * (0.3f + 0.9f * q), strokePaint(s.color, a * (1f - q), r * 0.12f))
                }
                c.drawCircle(x, y, r * 0.22f, fillPaint(a * tail))
            }
            TouchAnimation.SPLASH -> {
                // Center dot with 8 rays bursting outwards.
                c.drawCircle(x, y, r * 0.35f * (1f - 0.4f * p), fillPaint(a * tail))
                val inner = r * (0.45f + 0.6f * p)
                val outer = inner + r * 0.35f * (1f - p)
                val paint = strokePaint(s.color, a * (1f - p), r * 0.1f)
                for (i in 0 until 8) {
                    val ang = (i * PI / 4).toFloat()
                    c.drawLine(
                        x + cos(ang) * inner, y + sin(ang) * inner,
                        x + cos(ang) * outer, y + sin(ang) * outer, paint
                    )
                }
            }
            TouchAnimation.PULSE -> {
                val rr = r * (1f + 0.25f * sin(p * PI * 2).toFloat().coerceAtLeast(0f))
                c.drawCircle(x, y, rr, fillPaint(a * tail))
                c.drawCircle(x, y, rr, strokePaint(outline, a * 0.8f * tail, r * 0.07f))
            }
            TouchAnimation.FADE -> {
                c.drawCircle(x, y, r, fillPaint(a * (1f - p)))
                c.drawCircle(x, y, r, strokePaint(outline, a * 0.8f * (1f - p), r * 0.07f))
            }
            TouchAnimation.DOT -> {
                // Small solid fingertip dot, like a presentation pointer.
                c.drawCircle(x, y, r * 0.45f, fillPaint(a * tail))
                c.drawCircle(x, y, r * 0.45f, strokePaint(outline, a * tail, r * 0.06f))
            }
            TouchAnimation.NONE -> {
                c.drawCircle(x, y, r, fillPaint(a))
                c.drawCircle(x, y, r, strokePaint(outline, a * 0.8f, r * 0.07f))
            }
        }
    }
}
