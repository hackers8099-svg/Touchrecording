package com.touchrecorder.app.recording

import android.content.Context
import android.hardware.display.DisplayManager
import android.media.MediaCodecInfo
import android.media.MediaCodecList
import android.media.MediaFormat
import android.os.Build
import android.util.DisplayMetrics
import android.view.Display
import com.touchrecorder.app.data.OrientationMode
import com.touchrecorder.app.data.RecorderSettings
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/** A video configuration that the device's H.264 encoder has confirmed it supports. */
data class VideoPlan(
    val codecName: String,
    val width: Int,
    val height: Int,
    val fps: Int,
    val bitrate: Int,
    val densityDpi: Int,
    val requestedFps: Int,
    val reducedSize: Boolean
) {
    val adjusted: Boolean get() = reducedSize || fps != requestedFps
}

/**
 * Turns the user's resolution / FPS / bitrate / orientation choices into a configuration the
 * hardware encoder really supports. Unsupported combinations are lowered step by step instead of
 * crashing; if nothing works an [RecorderException] with ENCODER_UNSUPPORTED is thrown.
 */
object VideoConfigResolver {

    private const val MIME = MediaFormat.MIMETYPE_VIDEO_AVC

    data class DisplayInfo(val width: Int, val height: Int, val densityDpi: Int)

    fun displayInfo(context: Context): DisplayInfo {
        val dm = context.getSystemService(DisplayManager::class.java)
        val display = dm?.getDisplay(Display.DEFAULT_DISPLAY)
        val metrics = DisplayMetrics()
        if (display != null) {
            @Suppress("DEPRECATION")
            display.getRealMetrics(metrics)
        } else {
            val res = context.resources.displayMetrics
            metrics.setTo(res)
        }
        return DisplayInfo(
            max(metrics.widthPixels, 1),
            max(metrics.heightPixels, 1),
            if (metrics.densityDpi > 0) metrics.densityDpi else DisplayMetrics.DENSITY_DEFAULT
        )
    }

    @Throws(RecorderException::class)
    fun resolve(context: Context, s: RecorderSettings): VideoPlan {
        val display = displayInfo(context)
        val portraitNow = display.height >= display.width
        val portrait = when (s.orientation) {
            OrientationMode.PORTRAIT -> true
            OrientationMode.LANDSCAPE -> false
            OrientationMode.AUTO -> portraitNow
        }
        val dShort = min(display.width, display.height)
        val dLong = max(display.width, display.height)
        val aspect = dLong.toDouble() / dShort.toDouble()

        // Never upscale beyond the real screen; "Auto" = native, capped at 1080p.
        val targetShort = min(s.shortSide ?: 1080, dShort)

        val codecInfo = findEncoder() ?: throw RecorderException(RecorderError.ENCODER_UNSUPPORTED)
        val caps = try {
            codecInfo.getCapabilitiesForType(MIME)
        } catch (e: IllegalArgumentException) {
            throw RecorderException(RecorderError.ENCODER_UNSUPPORTED, e)
        }
        val video = caps.videoCapabilities ?: throw RecorderException(RecorderError.ENCODER_UNSUPPORTED)

        val fpsCandidates = listOf(s.fps, 30, 24).filter { it <= s.fps }.distinct()
        for (fps in fpsCandidates) {
            var scale = 1.0
            while (scale >= 0.25) {
                val shortPx = (targetShort * scale)
                val longPx = shortPx * aspect
                val rawW = if (portrait) shortPx else longPx
                val rawH = if (portrait) longPx else shortPx
                val w = alignDown(rawW.roundToInt(), max(2, video.widthAlignment))
                val h = alignDown(rawH.roundToInt(), max(2, video.heightAlignment))
                if (w > 0 && h > 0 && isSupported(video, w, h, fps)) {
                    val bitrate = chooseBitrate(s.bitrateMbps, w, h, fps, video)
                    return VideoPlan(
                        codecName = codecInfo.name,
                        width = w,
                        height = h,
                        fps = fps,
                        bitrate = bitrate,
                        densityDpi = display.densityDpi,
                        requestedFps = s.fps,
                        reducedSize = scale < 0.999
                    )
                }
                scale -= 0.05
            }
        }
        throw RecorderException(RecorderError.ENCODER_UNSUPPORTED)
    }

    private fun isSupported(v: MediaCodecInfo.VideoCapabilities, w: Int, h: Int, fps: Int): Boolean =
        try {
            v.isSizeSupported(w, h) && v.areSizeAndRateSupported(w, h, fps.toDouble())
        } catch (e: Exception) {
            false
        }

    private fun chooseBitrate(
        userMbps: Int?,
        w: Int,
        h: Int,
        fps: Int,
        v: MediaCodecInfo.VideoCapabilities
    ): Int {
        val wanted = if (userMbps != null) {
            userMbps * 1_000_000L
        } else {
            // ~0.1 bits per pixel per frame, a good quality/size balance for screen content.
            (w.toLong() * h.toLong() * fps * 0.1).toLong().coerceIn(2_000_000L, 20_000_000L)
        }
        val range = v.bitrateRange
        return wanted.coerceIn(range.lower.toLong(), range.upper.toLong()).toInt()
    }

    private fun alignDown(value: Int, alignment: Int): Int = value - (value % alignment)

    /** Prefers a hardware H.264 encoder that accepts Surface input. */
    fun findEncoder(): MediaCodecInfo? {
        val all = try {
            MediaCodecList(MediaCodecList.REGULAR_CODECS).codecInfos.filter { info ->
                info.isEncoder && info.supportedTypes.any { it.equals(MIME, ignoreCase = true) }
            }
        } catch (e: Exception) {
            emptyList()
        }
        val surfaceCapable = all.filter { info ->
            try {
                info.getCapabilitiesForType(MIME).colorFormats
                    .contains(MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
            } catch (e: Exception) {
                false
            }
        }
        val pool = surfaceCapable.ifEmpty { all }
        return pool.firstOrNull { isHardware(it) } ?: pool.firstOrNull()
    }

    private fun isHardware(info: MediaCodecInfo): Boolean {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) return info.isHardwareAccelerated
        val n = info.name.lowercase()
        return !(n.startsWith("omx.google.") || n.startsWith("c2.android.") || n.contains(".sw."))
    }
}
