# Touch Recorder – no reflection-based libraries are used, default rules are sufficient.
-keep class com.touchrecorder.app.service.** { *; }
-keep class rikka.shizuku.** { *; }
